"use strict";
(() => {
  // extension/background/service-worker.ts
  var LOG = "[ai-helper][chatgpt-session]";
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      if (!message || message.type !== "ask-follow-up") {
        return false;
      }
      if (message.siteId === "chatgpt") {
        console.warn(
          `${LOG} Received chatgpt ask-follow-up in SW; content script should handle this directly.`
        );
        sendResponse({
          ok: false,
          error: "ChatGPT follow-ups must run in the page script. Reload chatgpt.com and try again."
        });
        return false;
      }
      sendResponse({
        ok: false,
        error: `No provider wired for siteId="${message.siteId}" yet.`
      });
      return false;
    }
  );
  console.info(
    "[ai-helper] Service worker ready (ChatGPT follow-ups run in-page)"
  );
})();
//# sourceMappingURL=service-worker.js.map
