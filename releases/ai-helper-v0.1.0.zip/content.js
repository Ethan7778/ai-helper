"use strict";
(() => {
  // extension/adapters/chatgpt.ts
  var ASSISTANT_SELECTORS = [
    '[data-message-author-role="assistant"]',
    '[data-turn="assistant"]',
    'article[data-turn-role="assistant"]',
    '[data-testid="assistant-message"]',
    '[data-testid*="assistant"]',
    'div[class*="agent-turn"]'
  ];
  var USER_SELECTORS = [
    '[data-message-author-role="user"]',
    '[data-turn="user"]',
    'article[data-turn-role="user"]'
  ];
  var MESSAGE_CONTENT_SELECTORS = ".markdown, .prose, [class*='markdown'], [class*='prose'], .whitespace-pre-wrap";
  var STOP_BUTTON_SELECTORS = [
    'button[aria-label="Stop generating"]',
    'button[aria-label*="Stop"]',
    '[data-testid="stop-button"]'
  ];
  function simpleHash(input) {
    let h = 2166136261;
    for (let i = 0; i < input.length; i++) {
      h ^= input.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(16);
  }
  function queryAll(selectors) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const sel of selectors) {
      for (const el of document.querySelectorAll(sel)) {
        if (seen.has(el)) continue;
        seen.add(el);
        out.push(el);
      }
    }
    return out;
  }
  function findChatScrollContainer() {
    const candidates = [
      document.querySelector("main"),
      document.querySelector('[class*="react-scroll"]'),
      document.querySelector('[data-testid="conversation-turns"]')?.parentElement,
      document.body
    ];
    for (const el of candidates) {
      if (el instanceof HTMLElement) return el;
    }
    return null;
  }
  function extractConversationIdFromUrl() {
    const match = location.pathname.match(/\/(c|share)\/([a-zA-Z0-9-]+)/);
    if (match) return match[2];
    return `anon-${location.pathname || "root"}`;
  }
  var ROLE_SELECTOR = "[data-message-author-role], [data-turn], [data-turn-role]";
  function createChatGptAdapter() {
    let warnedEmpty = false;
    let warnedNoScroll = false;
    let warnedEmptyExcerpt = false;
    const adapter = {
      siteId: "chatgpt",
      getConversationId() {
        return extractConversationIdFromUrl();
      },
      getConversationExcerpt(maxChars) {
        const turns = Array.from(
          document.querySelectorAll(ROLE_SELECTOR)
        );
        if (turns.length === 0) {
          return "";
        }
        warnedEmptyExcerpt = false;
        const chunks = [];
        for (const turn of turns) {
          const role = turn.getAttribute("data-message-author-role") || turn.getAttribute("data-turn") || turn.getAttribute("data-turn-role") || "unknown";
          if (role !== "user" && role !== "assistant") continue;
          const body = turn.querySelector(
            ".markdown, .prose, [class*='markdown']"
          ) ?? turn;
          const text = (body.innerText || "").replace(/\s+/g, " ").trim();
          if (!text) continue;
          chunks.push(`${role.toUpperCase()}: ${text}`);
        }
        if (chunks.length === 0) {
          if (!warnedEmptyExcerpt) {
            console.warn(
              "[ai-helper][chatgpt-session] Conversation excerpt: turns present but no usable text."
            );
            warnedEmptyExcerpt = true;
          }
          return "";
        }
        let excerpt = "";
        for (let i = chunks.length - 1; i >= 0; i--) {
          const next = excerpt ? `${chunks[i]}

${excerpt}` : chunks[i];
          if (next.length > maxChars) {
            if (!excerpt) {
              excerpt = chunks[i].slice(-maxChars);
            }
            break;
          }
          excerpt = next;
        }
        return excerpt;
      },
      getMessageContainers() {
        const turns = queryAll(ASSISTANT_SELECTORS);
        const users = queryAll(USER_SELECTORS);
        if (turns.length === 0 && users.length > 0 && !warnedEmpty) {
          console.warn(
            `[ai-helper] ChatGPT adapter: found user turns but no assistant messages (tried: ${ASSISTANT_SELECTORS.join(", ")}). The site DOM may have changed.`
          );
          warnedEmpty = true;
        }
        if (turns.length > 0) {
          warnedEmpty = false;
        }
        return turns.map((turn) => {
          const content = turn.querySelector(MESSAGE_CONTENT_SELECTORS) ?? turn;
          return content;
        });
      },
      getMessageId(el) {
        const turn = el.closest(ASSISTANT_SELECTORS.join(",")) ?? el;
        const fromAttr = turn.getAttribute("data-message-id") || turn.getAttribute("data-testid") || turn.id;
        if (fromAttr) return fromAttr;
        const containers = adapter.getMessageContainers();
        const index = containers.indexOf(el);
        const prefix = (el.innerText || "").slice(0, 80).replace(/\s+/g, " ");
        return `hash-${simpleHash(`${index}:${prefix}`)}`;
      },
      isMessageComplete(el) {
        for (const sel of STOP_BUTTON_SELECTORS) {
          if (document.querySelector(sel)) {
            const near = el.closest("article, [data-testid]") ?? el.parentElement;
            if (near?.querySelector(sel) || document.querySelector(sel)) {
              return false;
            }
          }
        }
        if (el.getAttribute("data-is-streaming") === "true" || el.querySelector('[data-is-streaming="true"]')) {
          return false;
        }
        return true;
      },
      onNewMessage(cb) {
        const seen = /* @__PURE__ */ new WeakSet();
        const reportExisting = () => {
          for (const el of adapter.getMessageContainers()) {
            if (seen.has(el)) continue;
            seen.add(el);
            cb(el);
          }
        };
        reportExisting();
        const root = findChatScrollContainer();
        if (!root) {
          if (!warnedNoScroll) {
            console.error(
              "[ai-helper] ChatGPT adapter: could not find chat scroll container for MutationObserver."
            );
            warnedNoScroll = true;
          }
          return;
        }
        let quietTimer = null;
        const observer = new MutationObserver(() => {
          if (quietTimer) clearTimeout(quietTimer);
          quietTimer = setTimeout(() => {
            reportExisting();
          }, 500);
        });
        observer.observe(root, { childList: true, subtree: true });
        let lastHref = location.href;
        setInterval(() => {
          if (location.href !== lastHref) {
            lastHref = location.href;
            warnedEmpty = false;
            reportExisting();
          }
        }, 1e3);
      }
    };
    return adapter;
  }

  // extension/core/anchor.ts
  function getTextOffset(root, node, offset) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let total = 0;
    let current = walker.nextNode();
    while (current) {
      if (current === node) {
        return total + offset;
      }
      total += (current.textContent ?? "").length;
      current = walker.nextNode();
    }
    if (root.contains(node)) {
      try {
        const range = document.createRange();
        range.selectNodeContents(root);
        range.setEnd(node, offset);
        return range.toString().length;
      } catch {
        return total;
      }
    }
    return -1;
  }
  function getPlainText(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let text = "";
    let current = walker.nextNode();
    while (current) {
      text += current.textContent ?? "";
      current = walker.nextNode();
    }
    return text;
  }
  function filterNonOverlapping(threads, textLen) {
    const sorted = [...threads].sort((a, b) => a.anchorStart - b.anchorStart);
    const kept = [];
    let lastEnd = -1;
    for (const t of sorted) {
      if (t.anchorStart < 0 || t.anchorEnd > textLen || t.anchorStart >= t.anchorEnd) {
        continue;
      }
      if (t.anchorStart < lastEnd) {
        console.warn(
          "[ai-helper] Skipping overlapping highlight",
          t.id,
          `(${t.anchorStart}-${t.anchorEnd} overlaps prior end ${lastEnd})`
        );
        continue;
      }
      kept.push(t);
      lastEnd = t.anchorEnd;
    }
    return kept;
  }
  function getSelectionAnchor(messageRoots) {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || sel.rangeCount === 0) {
      return null;
    }
    const range = sel.getRangeAt(0);
    const { startContainer, endContainer } = range;
    const startOffset = range.startOffset;
    const endOffset = range.endOffset;
    let messageRoot = messageRoots.find(
      (root) => root.contains(startContainer) && root.contains(endContainer)
    ) ?? null;
    if (!messageRoot) {
      messageRoot = findAssistantRootFromNode(startContainer);
      if (!messageRoot || !messageRoot.contains(startContainer) || !messageRoot.contains(endContainer)) {
        return null;
      }
    }
    const start = getTextOffset(messageRoot, startContainer, startOffset);
    const end = getTextOffset(messageRoot, endContainer, endOffset);
    if (start < 0 || end < 0 || start >= end) {
      return null;
    }
    const quotedText = range.toString();
    if (!quotedText.trim()) {
      return null;
    }
    let rect = range.getBoundingClientRect();
    if (!rect.width && !rect.height || Number.isNaN(rect.top)) {
      const rects = range.getClientRects();
      if (rects.length > 0) {
        rect = rects[0];
      }
    }
    return {
      messageRoot,
      start,
      end,
      quotedText,
      rect
    };
  }
  function findAssistantRootFromNode(node) {
    const el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    if (!el) return null;
    const turn = el.closest(
      [
        '[data-message-author-role="assistant"]',
        '[data-turn="assistant"]',
        'article[data-turn-role="assistant"]',
        '[data-testid="assistant-message"]',
        '[data-testid*="assistant"]'
      ].join(", ")
    );
    if (!turn) return null;
    return turn.querySelector(
      ".markdown, .prose, [class*='markdown'], [class*='prose'], .whitespace-pre-wrap"
    ) ?? turn;
  }
  function getAnchorRect(anchor) {
    if (!anchor.messageRoot.isConnected) return null;
    const range = rangeFromOffsets(anchor.messageRoot, anchor.start, anchor.end);
    return range?.getBoundingClientRect() ?? null;
  }
  function rangeFromOffsets(root, start, end) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let offset = 0;
    let startNode = null;
    let startOff = 0;
    let endNode = null;
    let endOff = 0;
    let current = walker.nextNode();
    while (current) {
      const node = current;
      const len = node.data.length;
      const nodeStart = offset;
      const nodeEnd = offset + len;
      if (!startNode && start >= nodeStart && start <= nodeEnd) {
        startNode = node;
        startOff = start - nodeStart;
      }
      if (!endNode && end >= nodeStart && end <= nodeEnd) {
        endNode = node;
        endOff = end - nodeStart;
        break;
      }
      offset = nodeEnd;
      current = walker.nextNode();
    }
    if (!startNode || !endNode) return null;
    try {
      const range = document.createRange();
      range.setStart(startNode, startOff);
      range.setEnd(endNode, endOff);
      return range;
    } catch {
      return null;
    }
  }
  var ASK_BUTTON_ID = "ai-helper-ask-btn";
  var ASK_BUTTON_INJECTED = "ai-helper-ask-injected";
  function styleAskButton(button, inline) {
    Object.assign(button.style, {
      position: inline ? "static" : "fixed",
      zIndex: inline ? "auto" : "2147483646",
      margin: inline ? "0 0 0 6px" : "0",
      padding: "6px 10px",
      fontSize: "12px",
      fontFamily: "system-ui, sans-serif",
      lineHeight: "1.2",
      border: "1px solid #ccc",
      borderRadius: "6px",
      background: "#fff",
      color: "#111",
      boxShadow: inline ? "none" : "0 2px 8px rgba(0,0,0,0.15)",
      cursor: "pointer",
      whiteSpace: "nowrap",
      flexShrink: "0"
    });
  }
  function createAskButton(getPending, onAsk, hide, inline) {
    const button = document.createElement("button");
    button.id = inline ? ASK_BUTTON_INJECTED : ASK_BUTTON_ID;
    button.type = "button";
    button.textContent = "Ask about this";
    button.dataset.aiHelperAsk = "1";
    styleAskButton(button, inline);
    button.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
    });
    button.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const anchor = getPending();
      if (anchor) onAsk(anchor);
      hide();
      window.getSelection()?.removeAllRanges();
    });
    return button;
  }
  function findNativeAskToolbar() {
    const candidates = Array.from(
      document.querySelectorAll("button, [role='button'], a")
    );
    const native = candidates.find((el) => {
      if (el.dataset.aiHelperAsk) return false;
      const txt = (el.textContent || "").replace(/\s+/g, " ").trim();
      return txt === "Ask ChatGPT" || txt.startsWith("Ask ChatGPT");
    });
    if (!native?.parentElement) return null;
    return { button: native, row: native.parentElement };
  }
  function attachSelectionHandler(getMessageRoots, onAsk) {
    let button = null;
    let pending = null;
    let toolbarObserver = null;
    let injectTimer = null;
    let selectionTimer = null;
    const clearObserver = () => {
      toolbarObserver?.disconnect();
      toolbarObserver = null;
      if (injectTimer) {
        clearTimeout(injectTimer);
        injectTimer = null;
      }
    };
    const hide = () => {
      clearObserver();
      document.querySelectorAll("[data-ai-helper-ask='1']").forEach((el) => el.remove());
      button = null;
      pending = null;
    };
    const positionFloating = (el, rect) => {
      const top = Math.min(
        window.innerHeight - 40,
        Math.max(8, rect.bottom + 8)
      );
      const left = Math.min(
        window.innerWidth - 160,
        Math.max(8, rect.left)
      );
      el.style.top = `${top}px`;
      el.style.left = `${left}px`;
    };
    const placeFloating = (anchor) => {
      const existing = document.getElementById(
        ASK_BUTTON_ID
      );
      if (existing) {
        button = existing;
        positionFloating(existing, anchor.rect);
        return;
      }
      button = createAskButton(() => pending, onAsk, hide, false);
      positionFloating(button, anchor.rect);
      document.body.appendChild(button);
    };
    const tryInjectIntoToolbar = () => {
      if (!pending) return false;
      if (document.getElementById(ASK_BUTTON_INJECTED)) return true;
      const found = findNativeAskToolbar();
      if (!found) return false;
      const injected = createAskButton(() => pending, onAsk, hide, true);
      if (found.button.nextSibling) {
        found.button.parentElement?.insertBefore(
          injected,
          found.button.nextSibling
        );
      } else {
        found.row.appendChild(injected);
      }
      try {
        const cs = getComputedStyle(found.button);
        injected.style.fontSize = cs.fontSize || injected.style.fontSize;
        injected.style.borderRadius = cs.borderRadius || injected.style.borderRadius;
        injected.style.padding = cs.padding || injected.style.padding;
        injected.style.fontFamily = cs.fontFamily || injected.style.fontFamily;
      } catch {
      }
      return true;
    };
    const show = (anchor) => {
      pending = anchor;
      placeFloating(anchor);
      tryInjectIntoToolbar();
      if (!toolbarObserver) {
        toolbarObserver = new MutationObserver(() => {
          if (!pending) return;
          tryInjectIntoToolbar();
          if (!document.getElementById(ASK_BUTTON_ID)) {
            placeFloating(pending);
          }
        });
        toolbarObserver.observe(document.body, {
          childList: true,
          subtree: true
        });
        injectTimer = setTimeout(() => clearObserver(), 4e3);
      }
    };
    const refreshFromSelection = () => {
      const anchor = getSelectionAnchor(getMessageRoots());
      if (anchor) {
        show(anchor);
        return;
      }
      if (pending && document.getElementById(ASK_BUTTON_ID)) {
        return;
      }
      if (pending && document.getElementById(ASK_BUTTON_INJECTED)) {
        placeFloating(pending);
        return;
      }
      const overAsk = Array.from(
        document.querySelectorAll("[data-ai-helper-ask='1']")
      );
      if (overAsk.some((el) => el.matches(":hover"))) return;
    };
    const scheduleRefresh = (delayMs) => {
      if (selectionTimer) clearTimeout(selectionTimer);
      selectionTimer = setTimeout(() => {
        selectionTimer = null;
        refreshFromSelection();
      }, delayMs);
    };
    const onMouseUp = () => scheduleRefresh(40);
    const onTouchEnd = () => scheduleRefresh(60);
    const onKeyUp = (e) => {
      if (e.key === "Shift" || e.key.startsWith("Arrow") || e.key === "Home" || e.key === "End") {
        scheduleRefresh(40);
      }
    };
    const onSelectionChange = () => scheduleRefresh(80);
    const onPointerDown = (e) => {
      const t = e.target;
      if (!(t instanceof Node)) return;
      if (t instanceof Element && (t.closest("[data-ai-helper-ask='1']") || t.closest(`#${ASK_BUTTON_ID}`) || t.closest(`#${ASK_BUTTON_INJECTED}`))) {
        return;
      }
      if (pending) {
        setTimeout(() => {
          const sel = window.getSelection();
          if (sel && !sel.isCollapsed) return;
          hide();
        }, 0);
      }
    };
    const onKeyDown = (e) => {
      if (e.key === "Escape" && pending) hide();
    };
    const onScroll = () => {
      if (!pending) return;
      if (!pending.messageRoot.isConnected) {
        hide();
        return;
      }
      const live = getSelectionAnchor(getMessageRoots());
      const rect = live && live.messageRoot === pending.messageRoot ? live.rect : getAnchorRect(pending);
      if (!rect || rect.width === 0 && rect.height === 0) {
        document.getElementById(ASK_BUTTON_ID)?.remove();
        if (button?.id === ASK_BUTTON_ID) button = null;
        return;
      }
      if (live) pending = live;
      else pending = { ...pending, rect };
      placeFloating(pending);
      tryInjectIntoToolbar();
    };
    document.addEventListener("mouseup", onMouseUp, true);
    document.addEventListener("touchend", onTouchEnd, true);
    document.addEventListener("keyup", onKeyUp, true);
    document.addEventListener("keydown", onKeyDown, true);
    document.addEventListener("pointerdown", onPointerDown, true);
    document.addEventListener("selectionchange", onSelectionChange);
    window.addEventListener("scroll", onScroll, true);
    return () => {
      document.removeEventListener("mouseup", onMouseUp, true);
      document.removeEventListener("touchend", onTouchEnd, true);
      document.removeEventListener("keyup", onKeyUp, true);
      document.removeEventListener("keydown", onKeyDown, true);
      document.removeEventListener("pointerdown", onPointerDown, true);
      document.removeEventListener("selectionchange", onSelectionChange);
      window.removeEventListener("scroll", onScroll, true);
      if (selectionTimer) clearTimeout(selectionTimer);
      hide();
    };
  }
  function unwrapHighlights(root) {
    const marks = Array.from(
      root.querySelectorAll("mark[data-thread-id]")
    );
    for (const mark of marks) {
      const parent = mark.parentNode;
      if (!parent) continue;
      while (mark.firstChild) {
        parent.insertBefore(mark.firstChild, mark);
      }
      parent.removeChild(mark);
    }
    root.normalize();
  }
  function wrapHighlightsInPlace(root, threads) {
    unwrapHighlights(root);
    const textLen = getPlainText(root).length;
    const kept = filterNonOverlapping(threads, textLen);
    const ordered = [...kept].sort((a, b) => b.anchorStart - a.anchorStart);
    for (const t of ordered) {
      wrapTextRange(root, t.anchorStart, t.anchorEnd, t.id);
    }
  }
  function wrapTextRange(root, start, end, threadId) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let offset = 0;
    const segments = [];
    let current = walker.nextNode();
    while (current) {
      const node = current;
      if (node.parentElement?.closest("mark[data-thread-id]")) {
        offset += node.data.length;
        current = walker.nextNode();
        continue;
      }
      const len = node.data.length;
      const nodeStart = offset;
      const nodeEnd = offset + len;
      const from = Math.max(0, start - nodeStart);
      const to = Math.min(len, end - nodeStart);
      if (from < to) {
        segments.push({ node, from, to });
      }
      offset = nodeEnd;
      if (offset >= end) break;
      current = walker.nextNode();
    }
    for (let i = segments.length - 1; i >= 0; i--) {
      const seg = segments[i];
      wrapTextNodePortion(seg.node, seg.from, seg.to, threadId);
    }
  }
  function wrapTextNodePortion(node, from, to, threadId) {
    const parent = node.parentNode;
    if (!parent) return;
    const text = node.data;
    const before = text.slice(0, from);
    const mid = text.slice(from, to);
    const after = text.slice(to);
    if (!mid) return;
    const mark = document.createElement("mark");
    mark.dataset.threadId = threadId;
    mark.textContent = mid;
    mark.style.background = "rgba(201, 162, 39, 0.45)";
    mark.style.borderRadius = "2px";
    mark.style.cursor = "pointer";
    const frag = document.createDocumentFragment();
    if (before) frag.appendChild(document.createTextNode(before));
    frag.appendChild(mark);
    if (after) frag.appendChild(document.createTextNode(after));
    parent.replaceChild(frag, node);
  }
  function applyHighlightsToElement(el, threads) {
    const relevant = threads.filter((t) => t.anchorEnd > t.anchorStart);
    const rawText = getPlainText(el);
    if (!rawText) {
      return;
    }
    if (!el.dataset.aiHelperRaw) {
      el.dataset.aiHelperRaw = rawText;
    }
    wrapHighlightsInPlace(el, relevant);
  }

  // extension/core/text-clean.ts
  function cleanChatGptText(text) {
    if (!text) return "";
    let out = text;
    out = out.replace(
      /\uE200entity\uE202(\[[\s\S]*?\])\uE201/g,
      (_m, json) => {
        try {
          const arr = JSON.parse(json);
          if (Array.isArray(arr)) {
            const name = arr[1] ?? arr[0];
            return typeof name === "string" ? name : "";
          }
        } catch {
        }
        return "";
      }
    );
    out = out.replace(/\uE200\w+\uE202[\s\S]*?\uE201/g, "");
    out = out.replace(/[\uE000-\uF8FF]/g, "");
    out = out.replace(/[^\S\n]+/g, " ");
    out = out.replace(/ *\n */g, "\n");
    out = out.replace(/\n{3,}/g, "\n\n");
    return out.trim();
  }
  function formatReplyHtml(text) {
    const cleaned = cleanChatGptText(text);
    let html = escapeHtml(cleaned);
    html = html.replace(/(^|\n)#{1,6}\s+/g, "$1");
    html = html.replace(/(^|\n)&gt;\s?/g, "$1");
    html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
    html = html.replace(/(^|[^*])\*(?!\*)(.+?)\*(?!\*)/g, "$1<em>$2</em>");
    html = html.replace(/(^|\n)(?:-|\*) (.+)/g, "$1\u2022 $2");
    html = html.replace(/\n/g, "<br>");
    return html;
  }
  function escapeHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  // extension/core/chatgpt-auth.ts
  var LOG = "[ai-helper][chatgpt-session]";
  var SESSION_URL = "https://chatgpt.com/api/auth/session";
  async function fetchAccessTokenFromPage() {
    const res = await fetch(SESSION_URL, {
      credentials: "include",
      headers: { Accept: "application/json" }
    });
    if (res.status === 401 || res.status === 403) {
      console.error(`${LOG} /api/auth/session HTTP ${res.status}`);
      throw new Error(
        "ChatGPT session unavailable \u2014 reload the page or re-login, then try again."
      );
    }
    if (!res.ok) {
      console.error(`${LOG} /api/auth/session HTTP ${res.status}`);
      throw new Error(`Failed to read ChatGPT session (HTTP ${res.status}).`);
    }
    const data = await res.json();
    if (!data.accessToken) {
      console.error(`${LOG} session JSON missing accessToken`);
      throw new Error(
        "No ChatGPT access token found. Make sure you are logged in on chatgpt.com."
      );
    }
    return {
      accessToken: data.accessToken,
      userAgent: navigator.userAgent
    };
  }

  // node_modules/js-sha3/build/sha3.mjs
  var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
  function getDefaultExportFromCjs(x) {
    return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
  }
  var sha3$1 = { exports: {} };
  (function(module) {
    (function() {
      var INPUT_ERROR = "input is invalid type";
      var FINALIZE_ERROR = "finalize already called";
      var TUPLE_ACTIVE_ERROR = "no active tuple input";
      var TUPLE_INCOMPLETE_ERROR = "tuple input is incomplete";
      var TUPLE_LENGTH_ERROR = "tuple input exceeds declared length";
      var TUPLE_BYTE_LENGTH_ERROR = "tuple input byte length is invalid";
      var BLOCK_SIZE_ERROR = "block size is invalid";
      var WINDOW = typeof window === "object";
      var root = WINDOW ? window : {};
      if (root.JS_SHA3_NO_WINDOW) {
        WINDOW = false;
      }
      var WEB_WORKER = !WINDOW && typeof self === "object";
      var NODE_JS = !root.JS_SHA3_NO_NODE_JS && typeof process === "object" && process.versions && process.versions.node;
      if (NODE_JS) {
        root = commonjsGlobal;
      } else if (WEB_WORKER) {
        root = self;
      }
      var COMMON_JS = !root.JS_SHA3_NO_COMMON_JS && true && module.exports;
      var ARRAY_BUFFER = !root.JS_SHA3_NO_ARRAY_BUFFER && typeof ArrayBuffer !== "undefined";
      var HEX_CHARS = "0123456789abcdef".split("");
      var SHAKE_PADDING = [31, 7936, 2031616, 520093696];
      var CSHAKE_PADDING = [4, 1024, 262144, 67108864];
      var KECCAK_PADDING = [1, 256, 65536, 16777216];
      var PADDING = [6, 1536, 393216, 100663296];
      var SHIFT = [0, 8, 16, 24];
      var RC = [
        1,
        0,
        32898,
        0,
        32906,
        2147483648,
        2147516416,
        2147483648,
        32907,
        0,
        2147483649,
        0,
        2147516545,
        2147483648,
        32777,
        2147483648,
        138,
        0,
        136,
        0,
        2147516425,
        0,
        2147483658,
        0,
        2147516555,
        0,
        139,
        2147483648,
        32905,
        2147483648,
        32771,
        2147483648,
        32770,
        2147483648,
        128,
        2147483648,
        32778,
        0,
        2147483658,
        2147483648,
        2147516545,
        2147483648,
        32896,
        2147483648,
        2147483649,
        0,
        2147516424,
        2147483648
      ];
      var BITS = [224, 256, 384, 512];
      var SHAKE_BITS = [128, 256];
      var OUTPUT_TYPES = ["hex", "buffer", "arrayBuffer", "array", "digest"];
      var CSHAKE_BYTEPAD = {
        "128": 168,
        "256": 136
      };
      var isArray = root.JS_SHA3_NO_NODE_JS || !Array.isArray ? function(obj) {
        return Object.prototype.toString.call(obj) === "[object Array]";
      } : Array.isArray;
      var isView = ARRAY_BUFFER && (root.JS_SHA3_NO_ARRAY_BUFFER_IS_VIEW || !ArrayBuffer.isView) ? function(obj) {
        return typeof obj === "object" && obj.buffer && obj.buffer.constructor === ArrayBuffer;
      } : ArrayBuffer.isView;
      var formatMessage = function(message) {
        var type = typeof message;
        if (type === "string") {
          return [message, true];
        }
        if (type !== "object" || message === null) {
          throw new Error(INPUT_ERROR);
        }
        if (ARRAY_BUFFER && message.constructor === ArrayBuffer) {
          return [new Uint8Array(message), false];
        }
        if (!isArray(message) && !isView(message)) {
          throw new Error(INPUT_ERROR);
        }
        return [message, false];
      };
      var empty = function(message) {
        return formatMessage(message)[0].length === 0;
      };
      var cloneArray = function(array) {
        var newArray = [];
        for (var i2 = 0; i2 < array.length; ++i2) {
          newArray[i2] = array[i2];
        }
        return newArray;
      };
      var createOutputMethod = function(bits2, padding, outputType) {
        return function(message) {
          return new Keccak(bits2, padding, bits2).update(message)[outputType]();
        };
      };
      var createShakeOutputMethod = function(bits2, padding, outputType) {
        return function(message, outputBits) {
          return new Keccak(bits2, padding, outputBits).update(message)[outputType]();
        };
      };
      var createCshakeOutputMethod = function(bits2, padding, outputType) {
        return function(message, outputBits, n, s) {
          return methods["cshake" + bits2].update(message, outputBits, n, s)[outputType]();
        };
      };
      var createKmacOutputMethod = function(bits2, padding, xof, outputType) {
        return function(key, message, outputBits, s) {
          return methods[(xof ? "kmacxof" : "kmac") + bits2].update(key, message, outputBits, s)[outputType]();
        };
      };
      var createTupleHashOutputMethod = function(bits2, padding, xof, outputType) {
        return function(inputs, outputBits, s) {
          return methods[(xof ? "tuplehashxof" : "tuplehash") + bits2].update(inputs, outputBits, s)[outputType]();
        };
      };
      var createParallelHashOutputMethod = function(bits2, padding, xof, outputType) {
        return function(message, blockSize, outputBits, s) {
          return methods[(xof ? "parallelhashxof" : "parallelhash") + bits2].update(message, blockSize, outputBits, s)[outputType]();
        };
      };
      var createOutputMethods = function(method, createMethod2, bits2, padding) {
        for (var i2 = 0; i2 < OUTPUT_TYPES.length; ++i2) {
          var type = OUTPUT_TYPES[i2];
          method[type] = createMethod2(bits2, padding, type);
        }
        return method;
      };
      var createMethod = function(bits2, padding) {
        var method = createOutputMethod(bits2, padding, "hex");
        method.create = function() {
          return new Keccak(bits2, padding, bits2);
        };
        method.update = function(message) {
          return method.create().update(message);
        };
        return createOutputMethods(method, createOutputMethod, bits2, padding);
      };
      var createShakeMethod = function(bits2, padding) {
        var method = createShakeOutputMethod(bits2, padding, "hex");
        method.create = function(outputBits) {
          return new Keccak(bits2, padding, outputBits);
        };
        method.update = function(message, outputBits) {
          return method.create(outputBits).update(message);
        };
        return createOutputMethods(method, createShakeOutputMethod, bits2, padding);
      };
      var createCshakeMethod = function(bits2, padding) {
        var w = CSHAKE_BYTEPAD[bits2];
        var method = createCshakeOutputMethod(bits2, padding, "hex");
        method.create = function(outputBits, n, s) {
          if (empty(n) && empty(s)) {
            return methods["shake" + bits2].create(outputBits);
          } else {
            return new Keccak(bits2, padding, outputBits).bytepad([n, s], w);
          }
        };
        method.update = function(message, outputBits, n, s) {
          return method.create(outputBits, n, s).update(message);
        };
        return createOutputMethods(method, createCshakeOutputMethod, bits2, padding);
      };
      var createKmacMethod = function(bits2, padding, xof) {
        var w = CSHAKE_BYTEPAD[bits2];
        var method = createKmacOutputMethod(bits2, padding, xof, "hex");
        method.create = function(key, outputBits, s) {
          return new Kmac(bits2, padding, outputBits, xof).bytepad(["KMAC", s], w).bytepad([key], w);
        };
        method.update = function(key, message, outputBits, s) {
          return method.create(key, outputBits, s).update(message);
        };
        return createOutputMethods(method, function(b, p, outputType) {
          return createKmacOutputMethod(b, p, xof, outputType);
        }, bits2, padding);
      };
      var createTupleHashMethod = function(bits2, padding, xof) {
        var w = CSHAKE_BYTEPAD[bits2];
        var method = createTupleHashOutputMethod(bits2, padding, xof, "hex");
        method.create = function(outputBits, s) {
          return new TupleHash(bits2, padding, outputBits, xof).bytepad(["TupleHash", s], w);
        };
        method.update = function(inputs, outputBits, s) {
          if (!isArray(inputs)) {
            throw new Error(INPUT_ERROR);
          }
          var hash = method.create(outputBits, s);
          for (var i2 = 0; i2 < inputs.length; ++i2) {
            hash.update(inputs[i2]);
          }
          return hash;
        };
        return createOutputMethods(method, function(b, p, outputType) {
          return createTupleHashOutputMethod(b, p, xof, outputType);
        }, bits2, padding);
      };
      var createParallelHashMethod = function(bits2, padding, xof) {
        var w = CSHAKE_BYTEPAD[bits2];
        var method = createParallelHashOutputMethod(bits2, padding, xof, "hex");
        method.create = function(blockSize, outputBits, s) {
          if (typeof blockSize !== "number" || !isFinite(blockSize) || blockSize < 1 || Math.floor(blockSize) !== blockSize || blockSize > 268435455) {
            throw new Error(BLOCK_SIZE_ERROR);
          }
          var hash = new ParallelHash(bits2, padding, outputBits, xof, blockSize).bytepad(["ParallelHash", s], w);
          hash.encode(blockSize, false);
          return hash;
        };
        method.update = function(message, blockSize, outputBits, s) {
          return method.create(blockSize, outputBits, s).update(message);
        };
        return createOutputMethods(method, function(b, p, outputType) {
          return createParallelHashOutputMethod(b, p, xof, outputType);
        }, bits2, padding);
      };
      var algorithms = [
        { name: "keccak", padding: KECCAK_PADDING, bits: BITS, createMethod },
        { name: "sha3", padding: PADDING, bits: BITS, createMethod },
        { name: "shake", padding: SHAKE_PADDING, bits: SHAKE_BITS, createMethod: createShakeMethod },
        { name: "cshake", padding: CSHAKE_PADDING, bits: SHAKE_BITS, createMethod: createCshakeMethod },
        { name: "kmac", padding: CSHAKE_PADDING, bits: SHAKE_BITS, createMethod: function(bits2, padding) {
          return createKmacMethod(bits2, padding, false);
        } },
        { name: "kmacxof", padding: CSHAKE_PADDING, bits: SHAKE_BITS, createMethod: function(bits2, padding) {
          return createKmacMethod(bits2, padding, true);
        } },
        { name: "tuplehash", padding: CSHAKE_PADDING, bits: SHAKE_BITS, createMethod: function(bits2, padding) {
          return createTupleHashMethod(bits2, padding, false);
        } },
        { name: "tuplehashxof", padding: CSHAKE_PADDING, bits: SHAKE_BITS, createMethod: function(bits2, padding) {
          return createTupleHashMethod(bits2, padding, true);
        } },
        { name: "parallelhash", padding: CSHAKE_PADDING, bits: SHAKE_BITS, createMethod: function(bits2, padding) {
          return createParallelHashMethod(bits2, padding, false);
        } },
        { name: "parallelhashxof", padding: CSHAKE_PADDING, bits: SHAKE_BITS, createMethod: function(bits2, padding) {
          return createParallelHashMethod(bits2, padding, true);
        } }
      ];
      var methods = {}, methodNames = [];
      for (var i = 0; i < algorithms.length; ++i) {
        var algorithm = algorithms[i];
        var bits = algorithm.bits;
        for (var j = 0; j < bits.length; ++j) {
          var methodName = algorithm.name + "_" + bits[j];
          methodNames.push(methodName);
          methods[methodName] = algorithm.createMethod(bits[j], algorithm.padding);
          if (algorithm.name !== "sha3") {
            var newMethodName = algorithm.name + bits[j];
            methodNames.push(newMethodName);
            methods[newMethodName] = methods[methodName];
          }
        }
      }
      function Keccak(bits2, padding, outputBits) {
        this.blocks = [];
        this.s = [];
        this.padding = padding;
        this.outputBits = outputBits;
        this.reset = true;
        this.finalized = false;
        this.block = 0;
        this.start = 0;
        this.blockCount = 1600 - (bits2 << 1) >> 5;
        this.byteCount = this.blockCount << 2;
        this.outputBlocks = outputBits >> 5;
        this.extraBytes = (outputBits & 31) >> 3;
        for (var i2 = 0; i2 < 50; ++i2) {
          this.s[i2] = 0;
        }
      }
      Keccak.prototype.update = function(message) {
        if (this.finalized) {
          throw new Error(FINALIZE_ERROR);
        }
        var result = formatMessage(message);
        message = result[0];
        var isString = result[1];
        var blocks = this.blocks, byteCount = this.byteCount, length = message.length, blockCount = this.blockCount, index = 0, s = this.s, i2, code;
        while (index < length) {
          if (this.reset) {
            this.reset = false;
            blocks[0] = this.block;
            for (i2 = 1; i2 < blockCount + 1; ++i2) {
              blocks[i2] = 0;
            }
          }
          if (isString) {
            for (i2 = this.start; index < length && i2 < byteCount; ++index) {
              code = message.charCodeAt(index);
              if (code < 128) {
                blocks[i2 >> 2] |= code << SHIFT[i2++ & 3];
              } else if (code < 2048) {
                blocks[i2 >> 2] |= (192 | code >> 6) << SHIFT[i2++ & 3];
                blocks[i2 >> 2] |= (128 | code & 63) << SHIFT[i2++ & 3];
              } else if (code < 55296 || code >= 57344) {
                blocks[i2 >> 2] |= (224 | code >> 12) << SHIFT[i2++ & 3];
                blocks[i2 >> 2] |= (128 | code >> 6 & 63) << SHIFT[i2++ & 3];
                blocks[i2 >> 2] |= (128 | code & 63) << SHIFT[i2++ & 3];
              } else {
                code = 65536 + ((code & 1023) << 10 | message.charCodeAt(++index) & 1023);
                blocks[i2 >> 2] |= (240 | code >> 18) << SHIFT[i2++ & 3];
                blocks[i2 >> 2] |= (128 | code >> 12 & 63) << SHIFT[i2++ & 3];
                blocks[i2 >> 2] |= (128 | code >> 6 & 63) << SHIFT[i2++ & 3];
                blocks[i2 >> 2] |= (128 | code & 63) << SHIFT[i2++ & 3];
              }
            }
          } else {
            for (i2 = this.start; index < length && i2 < byteCount; ++index) {
              blocks[i2 >> 2] |= message[index] << SHIFT[i2++ & 3];
            }
          }
          this.lastByteIndex = i2;
          if (i2 >= byteCount) {
            this.start = i2 - byteCount;
            this.block = blocks[blockCount];
            for (i2 = 0; i2 < blockCount; ++i2) {
              s[i2] ^= blocks[i2];
            }
            f(s);
            this.reset = true;
          } else {
            this.start = i2;
          }
        }
        return this;
      };
      Keccak.prototype.encode = function(x, right) {
        var o = x & 255, n = 1;
        var bytes = [o];
        x = x >> 8;
        o = x & 255;
        while (o > 0) {
          bytes.unshift(o);
          x = x >> 8;
          o = x & 255;
          ++n;
        }
        if (right) {
          bytes.push(n);
        } else {
          bytes.unshift(n);
        }
        Keccak.prototype.update.call(this, bytes);
        return bytes.length;
      };
      Keccak.prototype.encodeString = function(str) {
        var result = formatMessage(str);
        str = result[0];
        var isString = result[1];
        var bytes = 0, length = str.length;
        if (isString) {
          for (var i2 = 0; i2 < str.length; ++i2) {
            var code = str.charCodeAt(i2);
            if (code < 128) {
              bytes += 1;
            } else if (code < 2048) {
              bytes += 2;
            } else if (code < 55296 || code >= 57344) {
              bytes += 3;
            } else {
              code = 65536 + ((code & 1023) << 10 | str.charCodeAt(++i2) & 1023);
              bytes += 4;
            }
          }
        } else {
          bytes = length;
        }
        bytes += this.encode(bytes * 8);
        Keccak.prototype.update.call(this, str);
        return bytes;
      };
      Keccak.prototype.bytepad = function(strs, w) {
        var bytes = this.encode(w);
        for (var i2 = 0; i2 < strs.length; ++i2) {
          bytes += this.encodeString(strs[i2]);
        }
        var paddingBytes = (w - bytes % w) % w;
        var zeros = [];
        zeros.length = paddingBytes;
        Keccak.prototype.update.call(this, zeros);
        return this;
      };
      Keccak.prototype.finalize = function() {
        if (this.finalized) {
          return;
        }
        this.finalized = true;
        var blocks = this.blocks, i2 = this.lastByteIndex, blockCount = this.blockCount, s = this.s;
        blocks[i2 >> 2] |= this.padding[i2 & 3];
        if (this.lastByteIndex === this.byteCount) {
          blocks[0] = blocks[blockCount];
          for (i2 = 1; i2 < blockCount + 1; ++i2) {
            blocks[i2] = 0;
          }
        }
        blocks[blockCount - 1] |= 2147483648;
        for (i2 = 0; i2 < blockCount; ++i2) {
          s[i2] ^= blocks[i2];
        }
        f(s);
      };
      Keccak.prototype.toString = Keccak.prototype.hex = function() {
        this.finalize();
        var blockCount = this.blockCount, s = this.s, outputBlocks = this.outputBlocks, extraBytes = this.extraBytes, i2 = 0, j2 = 0;
        var hex = "", block;
        while (j2 < outputBlocks) {
          for (i2 = 0; i2 < blockCount && j2 < outputBlocks; ++i2, ++j2) {
            block = s[i2];
            hex += HEX_CHARS[block >> 4 & 15] + HEX_CHARS[block & 15] + HEX_CHARS[block >> 12 & 15] + HEX_CHARS[block >> 8 & 15] + HEX_CHARS[block >> 20 & 15] + HEX_CHARS[block >> 16 & 15] + HEX_CHARS[block >> 28 & 15] + HEX_CHARS[block >> 24 & 15];
          }
          if (j2 % blockCount === 0) {
            s = cloneArray(s);
            f(s);
            i2 = 0;
          }
        }
        if (extraBytes) {
          block = s[i2];
          hex += HEX_CHARS[block >> 4 & 15] + HEX_CHARS[block & 15];
          if (extraBytes > 1) {
            hex += HEX_CHARS[block >> 12 & 15] + HEX_CHARS[block >> 8 & 15];
          }
          if (extraBytes > 2) {
            hex += HEX_CHARS[block >> 20 & 15] + HEX_CHARS[block >> 16 & 15];
          }
        }
        return hex;
      };
      Keccak.prototype.arrayBuffer = function() {
        this.finalize();
        var blockCount = this.blockCount, s = this.s, outputBlocks = this.outputBlocks, extraBytes = this.extraBytes, i2 = 0, j2 = 0;
        var bytes = this.outputBits >> 3;
        var buffer;
        if (extraBytes) {
          buffer = new ArrayBuffer(outputBlocks + 1 << 2);
        } else {
          buffer = new ArrayBuffer(bytes);
        }
        var array = new Uint32Array(buffer);
        while (j2 < outputBlocks) {
          for (i2 = 0; i2 < blockCount && j2 < outputBlocks; ++i2, ++j2) {
            array[j2] = s[i2];
          }
          if (j2 % blockCount === 0) {
            s = cloneArray(s);
            f(s);
          }
        }
        if (extraBytes) {
          array[j2] = s[i2];
          buffer = buffer.slice(0, bytes);
        }
        return buffer;
      };
      Keccak.prototype.buffer = Keccak.prototype.arrayBuffer;
      Keccak.prototype.digest = Keccak.prototype.array = function() {
        this.finalize();
        var blockCount = this.blockCount, s = this.s, outputBlocks = this.outputBlocks, extraBytes = this.extraBytes, i2 = 0, j2 = 0;
        var array = [], offset, block;
        while (j2 < outputBlocks) {
          for (i2 = 0; i2 < blockCount && j2 < outputBlocks; ++i2, ++j2) {
            offset = j2 << 2;
            block = s[i2];
            array[offset] = block & 255;
            array[offset + 1] = block >> 8 & 255;
            array[offset + 2] = block >> 16 & 255;
            array[offset + 3] = block >> 24 & 255;
          }
          if (j2 % blockCount === 0) {
            s = cloneArray(s);
            f(s);
          }
        }
        if (extraBytes) {
          offset = j2 << 2;
          block = s[i2];
          array[offset] = block & 255;
          if (extraBytes > 1) {
            array[offset + 1] = block >> 8 & 255;
          }
          if (extraBytes > 2) {
            array[offset + 2] = block >> 16 & 255;
          }
        }
        return array;
      };
      function Kmac(bits2, padding, outputBits, xof) {
        Keccak.call(this, bits2, padding, outputBits);
        this.xof = xof;
      }
      Kmac.prototype = new Keccak();
      Kmac.prototype.finalize = function() {
        if (!this.finalized) {
          this.encode(this.xof ? 0 : this.outputBits, true);
        }
        return Keccak.prototype.finalize.call(this);
      };
      function TupleHash(bits2, padding, outputBits, xof) {
        Kmac.call(this, bits2, padding, outputBits, xof);
        this.inputActive = false;
        this.inputBytesRemaining = 0;
      }
      TupleHash.prototype = new Kmac();
      TupleHash.prototype.getMessageByteLength = function(message) {
        var result = formatMessage(message);
        message = result[0];
        if (!result[1]) {
          return message.length;
        }
        var bytes = 0;
        for (var i2 = 0; i2 < message.length; ++i2) {
          var code = message.charCodeAt(i2);
          if (code < 128) {
            bytes += 1;
          } else if (code < 2048) {
            bytes += 2;
          } else if (code < 55296 || code >= 57344) {
            bytes += 3;
          } else {
            ++i2;
            bytes += 4;
          }
        }
        return bytes;
      };
      TupleHash.prototype.beginInput = function(byteLength) {
        if (this.inputActive) {
          throw new Error(TUPLE_INCOMPLETE_ERROR);
        }
        if (typeof byteLength !== "number" || !isFinite(byteLength) || byteLength < 0 || Math.floor(byteLength) !== byteLength || byteLength > 268435455) {
          throw new Error(TUPLE_BYTE_LENGTH_ERROR);
        }
        this.encode(byteLength * 8, false);
        if (byteLength !== 0) {
          this.inputActive = true;
          this.inputBytesRemaining = byteLength;
        }
        return this;
      };
      TupleHash.prototype._updateChunk = function(message, byteLength) {
        Kmac.prototype.update.call(this, message);
        this.inputBytesRemaining -= byteLength;
        if (this.inputBytesRemaining === 0) {
          this.inputActive = false;
        }
        return this;
      };
      TupleHash.prototype.updateChunk = function(message) {
        if (!this.inputActive) {
          throw new Error(TUPLE_ACTIVE_ERROR);
        }
        var byteLength = this.getMessageByteLength(message);
        if (byteLength > this.inputBytesRemaining) {
          throw new Error(TUPLE_LENGTH_ERROR);
        }
        return this._updateChunk(message, byteLength);
      };
      TupleHash.prototype.update = function(message) {
        var byteLength = this.getMessageByteLength(message);
        this.beginInput(byteLength);
        return this._updateChunk(message, byteLength);
      };
      TupleHash.prototype.finalize = function() {
        if (this.inputActive) {
          throw new Error(TUPLE_INCOMPLETE_ERROR);
        }
        return Kmac.prototype.finalize.call(this);
      };
      function ParallelHash(bits2, padding, outputBits, xof, blockSize) {
        Kmac.call(this, bits2, padding, outputBits, xof);
        this.bits = bits2;
        this.blockSize = blockSize;
        this.inner = null;
        this.innerBytes = 0;
        this.blockNumber = 0;
      }
      ParallelHash.prototype = new Kmac();
      ParallelHash.prototype._finishInner = function() {
        Kmac.prototype.update.call(this, this.inner.array());
        this.inner = null;
        this.innerBytes = 0;
        ++this.blockNumber;
      };
      ParallelHash.prototype._updateBytes = function(message) {
        var length = message.length;
        if (!length) {
          return;
        }
        var slice = message.subarray || message.slice;
        var blockSize = this.blockSize;
        var index = 0;
        while (index < length) {
          if (!this.inner) {
            this.inner = new Keccak(this.bits, SHAKE_PADDING, this.bits << 1);
          }
          var take = blockSize - this.innerBytes;
          if (length - index < take) {
            take = length - index;
          }
          this.inner.update(slice.call(message, index, index + take));
          this.innerBytes += take;
          index += take;
          if (this.innerBytes === blockSize) {
            this._finishInner();
          }
        }
      };
      ParallelHash.prototype.update = function(message) {
        if (this.finalized) {
          throw new Error(FINALIZE_ERROR);
        }
        var result = formatMessage(message);
        message = result[0];
        if (result[1]) {
          var bytes = [], length = message.length, index = 0, code, i2;
          for (i2 = 0; i2 < length; ++i2) {
            code = message.charCodeAt(i2);
            if (code < 128) {
              bytes[index++] = code;
            } else if (code < 2048) {
              bytes[index++] = 192 | code >>> 6;
              bytes[index++] = 128 | code & 63;
            } else if (code < 55296 || code >= 57344) {
              bytes[index++] = 224 | code >>> 12;
              bytes[index++] = 128 | code >>> 6 & 63;
              bytes[index++] = 128 | code & 63;
            } else {
              code = 65536 + ((code & 1023) << 10 | message.charCodeAt(++i2) & 1023);
              bytes[index++] = 240 | code >>> 18;
              bytes[index++] = 128 | code >>> 12 & 63;
              bytes[index++] = 128 | code >>> 6 & 63;
              bytes[index++] = 128 | code & 63;
            }
          }
          message = bytes;
        }
        this._updateBytes(message);
        return this;
      };
      ParallelHash.prototype.finalize = function() {
        if (!this.finalized) {
          if (this.inner) {
            this._finishInner();
          }
          this.encode(this.blockNumber, true);
        }
        return Kmac.prototype.finalize.call(this);
      };
      var f = function(s) {
        var h, l, n, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33, b34, b35, b36, b37, b38, b39, b40, b41, b42, b43, b44, b45, b46, b47, b48, b49;
        for (n = 0; n < 48; n += 2) {
          c0 = s[0] ^ s[10] ^ s[20] ^ s[30] ^ s[40];
          c1 = s[1] ^ s[11] ^ s[21] ^ s[31] ^ s[41];
          c2 = s[2] ^ s[12] ^ s[22] ^ s[32] ^ s[42];
          c3 = s[3] ^ s[13] ^ s[23] ^ s[33] ^ s[43];
          c4 = s[4] ^ s[14] ^ s[24] ^ s[34] ^ s[44];
          c5 = s[5] ^ s[15] ^ s[25] ^ s[35] ^ s[45];
          c6 = s[6] ^ s[16] ^ s[26] ^ s[36] ^ s[46];
          c7 = s[7] ^ s[17] ^ s[27] ^ s[37] ^ s[47];
          c8 = s[8] ^ s[18] ^ s[28] ^ s[38] ^ s[48];
          c9 = s[9] ^ s[19] ^ s[29] ^ s[39] ^ s[49];
          h = c8 ^ (c2 << 1 | c3 >>> 31);
          l = c9 ^ (c3 << 1 | c2 >>> 31);
          s[0] ^= h;
          s[1] ^= l;
          s[10] ^= h;
          s[11] ^= l;
          s[20] ^= h;
          s[21] ^= l;
          s[30] ^= h;
          s[31] ^= l;
          s[40] ^= h;
          s[41] ^= l;
          h = c0 ^ (c4 << 1 | c5 >>> 31);
          l = c1 ^ (c5 << 1 | c4 >>> 31);
          s[2] ^= h;
          s[3] ^= l;
          s[12] ^= h;
          s[13] ^= l;
          s[22] ^= h;
          s[23] ^= l;
          s[32] ^= h;
          s[33] ^= l;
          s[42] ^= h;
          s[43] ^= l;
          h = c2 ^ (c6 << 1 | c7 >>> 31);
          l = c3 ^ (c7 << 1 | c6 >>> 31);
          s[4] ^= h;
          s[5] ^= l;
          s[14] ^= h;
          s[15] ^= l;
          s[24] ^= h;
          s[25] ^= l;
          s[34] ^= h;
          s[35] ^= l;
          s[44] ^= h;
          s[45] ^= l;
          h = c4 ^ (c8 << 1 | c9 >>> 31);
          l = c5 ^ (c9 << 1 | c8 >>> 31);
          s[6] ^= h;
          s[7] ^= l;
          s[16] ^= h;
          s[17] ^= l;
          s[26] ^= h;
          s[27] ^= l;
          s[36] ^= h;
          s[37] ^= l;
          s[46] ^= h;
          s[47] ^= l;
          h = c6 ^ (c0 << 1 | c1 >>> 31);
          l = c7 ^ (c1 << 1 | c0 >>> 31);
          s[8] ^= h;
          s[9] ^= l;
          s[18] ^= h;
          s[19] ^= l;
          s[28] ^= h;
          s[29] ^= l;
          s[38] ^= h;
          s[39] ^= l;
          s[48] ^= h;
          s[49] ^= l;
          b0 = s[0];
          b1 = s[1];
          b32 = s[11] << 4 | s[10] >>> 28;
          b33 = s[10] << 4 | s[11] >>> 28;
          b14 = s[20] << 3 | s[21] >>> 29;
          b15 = s[21] << 3 | s[20] >>> 29;
          b46 = s[31] << 9 | s[30] >>> 23;
          b47 = s[30] << 9 | s[31] >>> 23;
          b28 = s[40] << 18 | s[41] >>> 14;
          b29 = s[41] << 18 | s[40] >>> 14;
          b20 = s[2] << 1 | s[3] >>> 31;
          b21 = s[3] << 1 | s[2] >>> 31;
          b2 = s[13] << 12 | s[12] >>> 20;
          b3 = s[12] << 12 | s[13] >>> 20;
          b34 = s[22] << 10 | s[23] >>> 22;
          b35 = s[23] << 10 | s[22] >>> 22;
          b16 = s[33] << 13 | s[32] >>> 19;
          b17 = s[32] << 13 | s[33] >>> 19;
          b48 = s[42] << 2 | s[43] >>> 30;
          b49 = s[43] << 2 | s[42] >>> 30;
          b40 = s[5] << 30 | s[4] >>> 2;
          b41 = s[4] << 30 | s[5] >>> 2;
          b22 = s[14] << 6 | s[15] >>> 26;
          b23 = s[15] << 6 | s[14] >>> 26;
          b4 = s[25] << 11 | s[24] >>> 21;
          b5 = s[24] << 11 | s[25] >>> 21;
          b36 = s[34] << 15 | s[35] >>> 17;
          b37 = s[35] << 15 | s[34] >>> 17;
          b18 = s[45] << 29 | s[44] >>> 3;
          b19 = s[44] << 29 | s[45] >>> 3;
          b10 = s[6] << 28 | s[7] >>> 4;
          b11 = s[7] << 28 | s[6] >>> 4;
          b42 = s[17] << 23 | s[16] >>> 9;
          b43 = s[16] << 23 | s[17] >>> 9;
          b24 = s[26] << 25 | s[27] >>> 7;
          b25 = s[27] << 25 | s[26] >>> 7;
          b6 = s[36] << 21 | s[37] >>> 11;
          b7 = s[37] << 21 | s[36] >>> 11;
          b38 = s[47] << 24 | s[46] >>> 8;
          b39 = s[46] << 24 | s[47] >>> 8;
          b30 = s[8] << 27 | s[9] >>> 5;
          b31 = s[9] << 27 | s[8] >>> 5;
          b12 = s[18] << 20 | s[19] >>> 12;
          b13 = s[19] << 20 | s[18] >>> 12;
          b44 = s[29] << 7 | s[28] >>> 25;
          b45 = s[28] << 7 | s[29] >>> 25;
          b26 = s[38] << 8 | s[39] >>> 24;
          b27 = s[39] << 8 | s[38] >>> 24;
          b8 = s[48] << 14 | s[49] >>> 18;
          b9 = s[49] << 14 | s[48] >>> 18;
          s[0] = b0 ^ ~b2 & b4;
          s[1] = b1 ^ ~b3 & b5;
          s[10] = b10 ^ ~b12 & b14;
          s[11] = b11 ^ ~b13 & b15;
          s[20] = b20 ^ ~b22 & b24;
          s[21] = b21 ^ ~b23 & b25;
          s[30] = b30 ^ ~b32 & b34;
          s[31] = b31 ^ ~b33 & b35;
          s[40] = b40 ^ ~b42 & b44;
          s[41] = b41 ^ ~b43 & b45;
          s[2] = b2 ^ ~b4 & b6;
          s[3] = b3 ^ ~b5 & b7;
          s[12] = b12 ^ ~b14 & b16;
          s[13] = b13 ^ ~b15 & b17;
          s[22] = b22 ^ ~b24 & b26;
          s[23] = b23 ^ ~b25 & b27;
          s[32] = b32 ^ ~b34 & b36;
          s[33] = b33 ^ ~b35 & b37;
          s[42] = b42 ^ ~b44 & b46;
          s[43] = b43 ^ ~b45 & b47;
          s[4] = b4 ^ ~b6 & b8;
          s[5] = b5 ^ ~b7 & b9;
          s[14] = b14 ^ ~b16 & b18;
          s[15] = b15 ^ ~b17 & b19;
          s[24] = b24 ^ ~b26 & b28;
          s[25] = b25 ^ ~b27 & b29;
          s[34] = b34 ^ ~b36 & b38;
          s[35] = b35 ^ ~b37 & b39;
          s[44] = b44 ^ ~b46 & b48;
          s[45] = b45 ^ ~b47 & b49;
          s[6] = b6 ^ ~b8 & b0;
          s[7] = b7 ^ ~b9 & b1;
          s[16] = b16 ^ ~b18 & b10;
          s[17] = b17 ^ ~b19 & b11;
          s[26] = b26 ^ ~b28 & b20;
          s[27] = b27 ^ ~b29 & b21;
          s[36] = b36 ^ ~b38 & b30;
          s[37] = b37 ^ ~b39 & b31;
          s[46] = b46 ^ ~b48 & b40;
          s[47] = b47 ^ ~b49 & b41;
          s[8] = b8 ^ ~b0 & b2;
          s[9] = b9 ^ ~b1 & b3;
          s[18] = b18 ^ ~b10 & b12;
          s[19] = b19 ^ ~b11 & b13;
          s[28] = b28 ^ ~b20 & b22;
          s[29] = b29 ^ ~b21 & b23;
          s[38] = b38 ^ ~b30 & b32;
          s[39] = b39 ^ ~b31 & b33;
          s[48] = b48 ^ ~b40 & b42;
          s[49] = b49 ^ ~b41 & b43;
          s[0] ^= RC[n];
          s[1] ^= RC[n + 1];
        }
      };
      if (COMMON_JS) {
        module.exports = methods;
      } else {
        for (i = 0; i < methodNames.length; ++i) {
          root[methodNames[i]] = methods[methodNames[i]];
        }
      }
    })();
  })(sha3$1);
  var sha3Exports = sha3$1.exports;
  var sha3 = /* @__PURE__ */ getDefaultExportFromCjs(sha3Exports);
  var {
    sha3_224,
    sha3_256,
    sha3_384,
    sha3_512,
    keccak_224,
    keccak_256,
    keccak_384,
    keccak_512,
    keccak224,
    keccak256,
    keccak384,
    keccak512,
    shake_128,
    shake_256,
    shake128,
    shake256,
    cshake_128,
    cshake_256,
    cshake128,
    cshake256,
    kmac_128,
    kmac_256,
    kmac128,
    kmac256,
    kmacxof_128,
    kmacxof_256,
    kmacxof128,
    kmacxof256,
    tuplehash_128,
    tuplehash_256,
    tuplehash128,
    tuplehash256,
    tuplehashxof_128,
    tuplehashxof_256,
    tuplehashxof128,
    tuplehashxof256,
    parallelhash_128,
    parallelhash_256,
    parallelhash128,
    parallelhash256,
    parallelhashxof_128,
    parallelhashxof_256,
    parallelhashxof128,
    parallelhashxof256
  } = sha3;

  // extension/core/prompt.ts
  function buildFollowUpPrompt(args) {
    const parts = [
      "You are answering a follow-up about a highlighted span from a ChatGPT reply.",
      "The user should not need the main chat; use only this context.",
      "",
      "## Highlighted span",
      args.quotedText.trim() || "(empty)",
      "",
      "## Surrounding message",
      args.surroundingContext.trim() || "(none)",
      "",
      "## Earlier conversation excerpt",
      args.conversationExcerpt.trim() || "(none)",
      "",
      "## Question",
      args.question.trim()
    ];
    return parts.join("\n");
  }

  // extension/core/sse-parse.ts
  function extractTextFromMessage(message) {
    if (!message || typeof message !== "object") return "";
    const content = message.content;
    if (!content || typeof content !== "object") return "";
    const parts = content.parts;
    if (!Array.isArray(parts)) return "";
    return parts.filter((p) => typeof p === "string").join("");
  }
  function parseConversationSseText(text) {
    let reply = "";
    let conversationId;
    let messageId;
    let topicId;
    let resumeToken;
    let lastPath = "";
    let lastOp = "append";
    let handedOff = false;
    const eventTypes = [];
    const applyAssistantMessage = (msg) => {
      if (msg?.author?.role !== "assistant") return;
      const chunk = extractTextFromMessage(msg);
      if (chunk) reply = chunk;
      if (msg.id) messageId = msg.id;
    };
    for (const rawLine of text.split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (!payload || payload === "[DONE]" || payload === "v1") continue;
      let event;
      try {
        event = JSON.parse(payload);
      } catch {
        continue;
      }
      if (typeof event.type === "string") {
        eventTypes.push(event.type);
      }
      if (typeof event.conversation_id === "string") {
        conversationId = event.conversation_id;
      }
      if (event.type === "resume_conversation_token" || event.type === "stream_handoff") {
        handedOff = true;
        if (typeof event.conversation_id === "string") {
          conversationId = event.conversation_id;
        }
        if (event.type === "resume_conversation_token") {
          if (typeof event.token === "string") {
            resumeToken = event.token;
            const fromJwt = topicIdFromJwt(event.token);
            if (fromJwt) topicId = fromJwt;
          }
        }
        if (event.type === "stream_handoff" && Array.isArray(event.options)) {
          for (const opt of event.options) {
            if (!opt || typeof opt !== "object") continue;
            const o2 = opt;
            if ((o2.type === "subscribe_ws_topic" || o2.type === "resume_sse_endpoint") && typeof o2.topic_id === "string") {
              topicId = o2.topic_id;
              break;
            }
          }
        }
        continue;
      }
      if (typeof event.type === "string") {
        continue;
      }
      if (event.message && typeof event.message === "object") {
        applyAssistantMessage(
          event.message
        );
      }
      const v = event.v;
      const p = typeof event.p === "string" ? event.p : void 0;
      const o = typeof event.o === "string" ? event.o : void 0;
      if (p !== void 0) lastPath = p;
      if (o !== void 0) lastOp = o;
      if (v && typeof v === "object" && !Array.isArray(v)) {
        const nested = v;
        if (typeof nested.conversation_id === "string") {
          conversationId = nested.conversation_id;
        }
        if (nested.message) applyAssistantMessage(nested.message);
      }
      if (typeof v === "string") {
        const path = p ?? lastPath;
        const op = o ?? lastOp;
        const isParts = !path || path.includes("/parts/") || path.endsWith("/parts/0");
        if (isParts) {
          if (op === "append" || !o && !p) reply += v;
          else if (op === "replace" || op === "add") reply = v;
        }
      }
      if (o === "patch" && Array.isArray(v)) {
        for (const sub of v) {
          if (!sub || typeof sub !== "object") continue;
          const sp = sub;
          if (typeof sp.v === "string" && (sp.p || "").includes("parts")) {
            if (sp.o === "append") reply += sp.v;
            else if (sp.o === "replace" || sp.o === "add") reply = sp.v;
          }
          if (sp.v && typeof sp.v === "object" && sp.v.message) {
            applyAssistantMessage(
              sp.v.message
            );
          }
        }
      }
    }
    if (!conversationId) {
      const match = text.match(/"conversation_id"\s*:\s*"([a-f0-9-]{10,})"/i);
      if (match?.[1]) conversationId = match[1];
    }
    if (!topicId) {
      const match = text.match(
        /"topic_id"\s*:\s*"(conversation-turn-[a-f0-9-]+)"/i
      );
      if (match?.[1]) topicId = match[1];
    }
    return {
      reply,
      conversationId,
      messageId,
      topicId,
      resumeToken,
      handedOff: handedOff && !reply.trim(),
      eventTypes
    };
  }
  function topicIdFromJwt(token) {
    try {
      const parts = token.split(".");
      if (parts.length < 2) return void 0;
      const json = atob(parts[1].replace(/-/g, "+").replace(/_/g, "/"));
      const payload = JSON.parse(json);
      return typeof payload.turn_topic_id === "string" ? payload.turn_topic_id : void 0;
    } catch {
      return void 0;
    }
  }
  function extractLatestAssistantFromConversation(data) {
    if (!data || typeof data !== "object") return null;
    const mapping = data.mapping;
    if (!mapping || typeof mapping !== "object") return null;
    let best = null;
    for (const node of Object.values(mapping)) {
      if (!node || typeof node !== "object") continue;
      const msg = node.message;
      if (!msg || typeof msg !== "object") continue;
      const message = msg;
      if (message.author?.role !== "assistant") continue;
      const text = extractTextFromMessage(message);
      if (!text.trim()) continue;
      const time = typeof message.create_time === "number" ? message.create_time : 0;
      if (!best || time >= best.time) {
        best = {
          text,
          messageId: message.id,
          status: message.status,
          time
        };
      }
    }
    return best ? { text: best.text, messageId: best.messageId, status: best.status } : null;
  }

  // extension/background/chatgpt-session.ts
  var LOG2 = "[ai-helper][chatgpt-session]";
  var REQUIREMENTS_URL = "https://chatgpt.com/backend-api/sentinel/chat-requirements";
  var CONVERSATION_URLS = [
    "https://chatgpt.com/backend-api/f/conversation",
    "https://chatgpt.com/backend-api/conversation"
  ];
  var MODELS_URL = "https://chatgpt.com/backend-api/models";
  var CONVERSATION_DETAIL_URL = "https://chatgpt.com/backend-api/conversation";
  function uuid() {
    if (typeof crypto !== "undefined" && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = Math.random() * 16 | 0;
      const v = c === "x" ? r : r & 3 | 8;
      return v.toString(16);
    });
  }
  function bytesFromHex(hex) {
    const clean = hex.length % 2 === 0 ? hex : `0${hex}`;
    const out = new Uint8Array(clean.length / 2);
    for (let i = 0; i < out.length; i++) {
      out[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
    }
    return out;
  }
  function compareBytes(a, b) {
    const n = Math.min(a.length, b.length);
    for (let i = 0; i < n; i++) {
      if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
    }
    return a.length === b.length ? 0 : a.length < b.length ? -1 : 1;
  }
  function toBase64(bytes) {
    let binary = "";
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }
  function utf8(s) {
    return new TextEncoder().encode(s);
  }
  function concatBytes(...parts) {
    const len = parts.reduce((n, p) => n + p.length, 0);
    const out = new Uint8Array(len);
    let offset = 0;
    for (const p of parts) {
      out.set(p, offset);
      offset += p.length;
    }
    return out;
  }
  function compact(arr, start = 0, end = arr.length) {
    return JSON.stringify(arr.slice(start, end)).slice(1, -1);
  }
  function parseTime() {
    const now = new Date(Date.now() - 5 * 3600 * 1e3);
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ];
    const pad = (n) => String(n).padStart(2, "0");
    return `${days[now.getUTCDay()]} ${months[now.getUTCMonth()]} ${pad(now.getUTCDate())} ${now.getUTCFullYear()} ${pad(now.getUTCHours())}:${pad(now.getUTCMinutes())}:${pad(
      now.getUTCSeconds()
    )} GMT-0500 (Eastern Standard Time)`;
  }
  function buildConfig(userAgent) {
    const perf = typeof performance !== "undefined" && performance.now ? performance.now() : Math.random() * 1e3;
    return [
      1920 + 1080,
      parseTime(),
      4294705152,
      0,
      userAgent,
      "",
      "",
      "en-US",
      "en-US",
      0,
      "webdriver\u2212false",
      "location",
      "window",
      perf,
      uuid(),
      "",
      8,
      Date.now() - perf
    ];
  }
  function generateAnswer(seed, diff, config) {
    const target = bytesFromHex(diff);
    const seedEncoded = utf8(seed);
    const part1 = utf8(`[${compact(config, 0, 3)},`);
    const part2 = utf8(`,${compact(config, 4, 9)},`);
    const part3 = utf8(`,${compact(config, 10)}]`);
    for (let i = 0; i < 5e5; i++) {
      const finalBytes = concatBytes(
        part1,
        utf8(String(i)),
        part2,
        utf8(String(i >> 1)),
        part3
      );
      const baseEncoded = toBase64(finalBytes);
      const digest = new Uint8Array(
        sha3_512.array(concatBytes(seedEncoded, utf8(baseEncoded)))
      );
      if (compareBytes(digest.subarray(0, target.length), target) <= 0) {
        return [baseEncoded, true];
      }
    }
    const fallback = "wQ8Lk5FbGpA2NcR9dShT6gYjU7VxZ4D" + toBase64(utf8(`"${seed}"`));
    return [fallback, false];
  }
  function solvePow(seed, difficulty, userAgent) {
    const config = buildConfig(userAgent);
    const [answer] = generateAnswer(seed, difficulty, config);
    return `gAAAAAB${answer}`;
  }
  function getRequirementsToken(userAgent) {
    const config = buildConfig(userAgent);
    const [require2] = generateAnswer(String(Math.random()), "0fffff", config);
    return `gAAAAAC${require2}`;
  }
  async function fetchSentinelTokens(accessToken, userAgent) {
    const p = getRequirementsToken(userAgent);
    const res = await fetch(REQUIREMENTS_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
        Accept: "*/*",
        "User-Agent": userAgent
      },
      body: JSON.stringify({ p })
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      console.error(
        `${LOG2} chat-requirements failed: HTTP ${res.status}`,
        body.slice(0, 300)
      );
      throw new Error(
        `ChatGPT session gate failed (chat-requirements HTTP ${res.status}). Reload chatgpt.com and try again.`
      );
    }
    const data = await res.json();
    if (!data.token) {
      console.error(`${LOG2} chat-requirements response missing token`);
      throw new Error("ChatGPT session gate returned no token.");
    }
    const out = {
      chatRequirements: data.token
    };
    const pow = data.proofofwork;
    if (pow?.required) {
      if (!pow.seed || !pow.difficulty) {
        throw new Error("ChatGPT proof-of-work challenge missing seed/difficulty.");
      }
      out.proof = solvePow(pow.seed, pow.difficulty, userAgent);
    }
    return out;
  }
  async function resolveModel(accessToken, userAgent) {
    try {
      const res = await fetch(MODELS_URL, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          Accept: "application/json",
          "User-Agent": userAgent
        }
      });
      if (!res.ok) {
        console.warn(`${LOG2} models fetch HTTP ${res.status}; using auto`);
        return "auto";
      }
      const data = await res.json();
      const slug = data.models?.[0]?.slug;
      if (slug) {
        console.info(`${LOG2} Using model "${slug}"`);
        return slug;
      }
    } catch (err) {
      console.warn(`${LOG2} models fetch failed; using auto`, err);
    }
    console.info(`${LOG2} Using model "auto"`);
    return "auto";
  }
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function getChatGptWebSocketUrl(accessToken, userAgent) {
    const res = await fetch("https://chatgpt.com/backend-api/celsius/ws/user", {
      credentials: "include",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: "*/*",
        "User-Agent": userAgent
      }
    });
    if (!res.ok) {
      throw new Error(`celsius/ws/user HTTP ${res.status}`);
    }
    const data = await res.json();
    if (!data.websocket_url) {
      throw new Error("celsius/ws/user returned no websocket_url");
    }
    return data.websocket_url;
  }
  function collectEncodedSseFromWsFrame(frame) {
    const out = [];
    if (!frame || typeof frame !== "object") return out;
    const f = frame;
    const walk = (node) => {
      if (!node || typeof node !== "object") return;
      if (Array.isArray(node)) {
        for (const item of node) walk(item);
        return;
      }
      const obj = node;
      if (typeof obj.encoded_item === "string" && obj.encoded_item) {
        out.push(obj.encoded_item);
      }
      for (const value of Object.values(obj)) {
        if (value && typeof value === "object") walk(value);
      }
    };
    if (f.type === "reply" && f.reply && typeof f.reply === "object") {
      const reply = f.reply;
      if (Array.isArray(reply.catchups)) {
        for (const cu of reply.catchups) walk(cu);
      }
    }
    walk(f);
    return out;
  }
  async function recoverViaWebSocket(accessToken, userAgent, topicId, onPartial, timeoutMs = 9e4) {
    const wsUrl = await getChatGptWebSocketUrl(accessToken, userAgent);
    let host = wsUrl;
    try {
      host = new URL(wsUrl).host;
    } catch {
    }
    console.info(
      `${LOG2} Opening handoff WebSocket host=${host} topic=${topicId}`
    );
    return new Promise((resolve, reject) => {
      let settled = false;
      let reply = "";
      let messageId;
      let conversationId;
      let sseBuffer = "";
      let cmdId = 4;
      let framesSeen = 0;
      let encodedSeen = 0;
      const emit = (text) => {
        if (!text.trim()) return;
        onPartial?.(cleanChatGptText(text));
      };
      const finish = (ok, err) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try {
          ws.close();
        } catch {
        }
        if (ok && reply.trim()) {
          console.info(
            `${LOG2} WebSocket recovered reply (${reply.length} chars, frames=${framesSeen}, encoded=${encodedSeen})`
          );
          resolve({ reply, messageId, conversationId });
        } else {
          reject(
            new Error(
              err || `WebSocket handoff produced no reply (frames=${framesSeen}, encoded=${encodedSeen})`
            )
          );
        }
      };
      const timer = setTimeout(() => {
        if (reply.trim()) {
          finish(true);
        } else {
          finish(
            false,
            `WebSocket handoff timed out (frames=${framesSeen}, encoded=${encodedSeen})`
          );
        }
      }, timeoutMs);
      const ws = new WebSocket(wsUrl);
      ws.onopen = () => {
        console.info(`${LOG2} WebSocket open \u2014 subscribing to ${topicId}`);
        ws.send(
          JSON.stringify([
            {
              id: 1,
              command: {
                type: "connect",
                presence: { type: "presence", state: "background" }
              }
            },
            { id: 2, command: { type: "subscribe", topic_id: "calpico-chatgpt" } },
            { id: 3, command: { type: "subscribe", topic_id: "conversations" } },
            {
              id: ++cmdId,
              command: { type: "subscribe", topic_id: topicId, offset: "0" }
            }
          ])
        );
      };
      ws.onerror = () => {
        console.warn(`${LOG2} WebSocket error event`);
        finish(false, "WebSocket handoff connection error");
      };
      ws.onclose = (ev) => {
        console.info(
          `${LOG2} WebSocket closed code=${ev.code} reason=${ev.reason || "none"} frames=${framesSeen} encoded=${encodedSeen}`
        );
        if (!settled) {
          if (reply.trim()) finish(true);
          else {
            finish(
              false,
              `WebSocket closed before reply (code=${ev.code}, frames=${framesSeen}, encoded=${encodedSeen})`
            );
          }
        }
      };
      ws.onmessage = (ev) => {
        let frames = [];
        try {
          const parsed = JSON.parse(String(ev.data));
          frames = Array.isArray(parsed) ? parsed : [parsed];
        } catch {
          console.warn(
            `${LOG2} WebSocket non-JSON frame len=${String(ev.data).length}`
          );
          return;
        }
        for (const frame of frames) {
          framesSeen += 1;
          const fType = frame && typeof frame === "object" ? String(frame.type || "unknown") : typeof frame;
          if (framesSeen <= 10) {
            console.info(`${LOG2} WS frame#${framesSeen} type=${fType}`);
          }
          const encodedChunks = collectEncodedSseFromWsFrame(frame);
          for (const encoded of encodedChunks) {
            encodedSeen += 1;
            sseBuffer += `${encoded}
`;
            const parsed = parseConversationSseText(sseBuffer);
            if (parsed.conversationId) conversationId = parsed.conversationId;
            if (parsed.messageId) messageId = parsed.messageId;
            if (parsed.reply) {
              reply = parsed.reply;
              emit(reply);
            }
            if ((encoded.includes("[DONE]") || parsed.eventTypes.includes("message_stream_complete")) && reply.trim()) {
              finish(true);
              return;
            }
          }
          const direct = extractAssistantFromUnknownFrame(frame);
          if (direct?.text) {
            if (direct.text.length >= reply.length) {
              reply = direct.text;
              emit(reply);
            }
            if (direct.messageId) messageId = direct.messageId;
            if (direct.finished && reply.trim()) {
              finish(true);
              return;
            }
          }
        }
      };
    });
  }
  function extractAssistantFromUnknownFrame(frame) {
    if (!frame || typeof frame !== "object") return null;
    const stack = [frame];
    while (stack.length) {
      const cur = stack.pop();
      if (!cur || typeof cur !== "object") continue;
      if (Array.isArray(cur)) {
        stack.push(...cur);
        continue;
      }
      const obj = cur;
      if (obj.message && typeof obj.message === "object") {
        const msg = obj.message;
        if (msg.author?.role === "assistant") {
          const text = (() => {
            const content = msg.content;
            if (!content || typeof content !== "object") return "";
            const parts = content.parts;
            if (!Array.isArray(parts)) return "";
            return parts.filter((p) => typeof p === "string").join("");
          })();
          if (text.trim()) {
            return {
              text,
              messageId: msg.id,
              finished: msg.status === "finished_successfully" || msg.channel === "final"
            };
          }
        }
      }
      for (const v of Object.values(obj)) {
        if (v && typeof v === "object") stack.push(v);
      }
    }
    return null;
  }
  async function pollConversationForReply(accessToken, userAgent, conversationId, options) {
    const timeoutMs = options?.timeoutMs ?? 6e4;
    const intervalMs = options?.intervalMs ?? 1500;
    const started = Date.now();
    let consecutiveErrors = 0;
    let lastStatus = "";
    console.info(
      `${LOG2} Polling conversation ${conversationId} for reply\u2026`
    );
    while (Date.now() - started < timeoutMs) {
      await delay(intervalMs);
      try {
        const url = `${CONVERSATION_DETAIL_URL}/${encodeURIComponent(conversationId)}?include_visually_hidden_messages=true&include_widget_state=true`;
        const res = await fetch(url, {
          credentials: "include",
          headers: {
            Authorization: `Bearer ${accessToken}`,
            Accept: "application/json",
            "User-Agent": userAgent
          }
        });
        if (!res.ok) {
          consecutiveErrors += 1;
          lastStatus = `HTTP ${res.status}`;
          console.warn(
            `${LOG2} poll conversation HTTP ${res.status} (${consecutiveErrors})`
          );
          if (consecutiveErrors >= 8) {
            throw new Error(
              `Polling ChatGPT conversation failed repeatedly (${lastStatus}).`
            );
          }
          continue;
        }
        consecutiveErrors = 0;
        const data = await res.json();
        const found = extractLatestAssistantFromConversation(data);
        if (!found) {
          lastStatus = "no assistant message yet";
          continue;
        }
        lastStatus = found.status || "unknown";
        if (found.status === "finished_successfully" || found.text.trim().length > 0 && found.status !== "in_progress") {
          console.info(
            `${LOG2} Poll recovered reply (${found.text.length} chars, status=${found.status})`
          );
          return { reply: found.text, messageId: found.messageId };
        }
      } catch (err) {
        consecutiveErrors += 1;
        lastStatus = err instanceof Error ? err.message : String(err);
        console.warn(`${LOG2} poll error:`, lastStatus);
        if (consecutiveErrors >= 8) {
          throw new Error(
            `Polling ChatGPT conversation failed repeatedly (${lastStatus}).`
          );
        }
      }
    }
    throw new Error(
      `Timed out waiting for ChatGPT reply after stream handoff (last=${lastStatus}).`
    );
  }
  async function parseConversationStream(res, accessToken, userAgent, onPartial) {
    const contentType = res.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      const data = await res.json();
      console.error(`${LOG2} Unexpected JSON response (not SSE)`, data);
      throw new Error(
        typeof data?.detail === "string" ? data.detail : "ChatGPT returned JSON instead of a stream. Session may be blocked."
      );
    }
    const emit = (text2) => {
      if (!text2.trim()) return;
      onPartial?.(cleanChatGptText(text2));
    };
    let text = "";
    if (res.body) {
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let lastEmitted = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        text += decoder.decode(value, { stream: true });
        const live = parseConversationSseText(text);
        if (live.reply && live.reply !== lastEmitted) {
          lastEmitted = live.reply;
          emit(live.reply);
        }
      }
      text += decoder.decode();
    } else {
      text = await res.text();
    }
    const parsed = parseConversationSseText(text);
    console.info(
      `${LOG2} SSE events=[${parsed.eventTypes.join(",") || "none"}] handedOff=${parsed.handedOff} replyLen=${parsed.reply.length} conversationId=${parsed.conversationId || "none"} topicId=${parsed.topicId || "none"}`
    );
    if (parsed.reply.trim()) {
      emit(parsed.reply);
      return {
        reply: parsed.reply,
        conversationId: parsed.conversationId,
        messageId: parsed.messageId
      };
    }
    const tasks = [];
    if (parsed.topicId) {
      tasks.push(
        recoverViaWebSocket(
          accessToken,
          userAgent,
          parsed.topicId,
          onPartial
        ).then((r) => ({
          ...r,
          via: "websocket"
        }))
      );
    }
    if (parsed.conversationId) {
      tasks.push(
        pollConversationForReply(
          accessToken,
          userAgent,
          parsed.conversationId
        ).then((r) => {
          emit(r.reply);
          return {
            reply: r.reply,
            messageId: r.messageId,
            conversationId: parsed.conversationId,
            via: "poll"
          };
        })
      );
    }
    if (tasks.length === 0) {
      console.error(
        `${LOG2} Empty SSE with no topic/conversation to resume; head=${text.slice(0, 400)}`
      );
      throw new Error(
        "ChatGPT handed off the stream without a topic or conversation id. Reload and try again."
      );
    }
    console.info(
      `${LOG2} Recovering handoff via ${[
        parsed.topicId ? "websocket" : null,
        parsed.conversationId ? "poll" : null
      ].filter(Boolean).join("+")}`
    );
    try {
      const winner = await raceFirst(tasks);
      console.info(`${LOG2} Handoff recovered via ${winner.via}`);
      emit(winner.reply);
      return {
        reply: winner.reply,
        conversationId: winner.conversationId || parsed.conversationId,
        messageId: winner.messageId || parsed.messageId
      };
    } catch (err) {
      throw new Error(
        `Handoff recovery failed: ${err instanceof Error ? err.message : String(err)}`
      );
    }
  }
  function raceFirst(tasks) {
    return new Promise((resolve, reject) => {
      let pending = tasks.length;
      const errors = [];
      if (pending === 0) {
        reject(new Error("no recovery tasks"));
        return;
      }
      for (const task of tasks) {
        task.then(resolve, (err) => {
          errors.push(err instanceof Error ? err.message : String(err));
          pending -= 1;
          if (pending === 0) {
            reject(new Error(errors.join(" | ")));
          }
        });
      }
    });
  }
  async function postConversation(accessToken, userAgent, sentinel, prompt, model, sideConversationId, sideParentMessageId, onPartial) {
    const messageId = uuid();
    const parentMessageId = sideParentMessageId || "client-created-root";
    const body = {
      action: "next",
      messages: [
        {
          id: messageId,
          author: { role: "user" },
          create_time: Date.now() / 1e3,
          content: { content_type: "text", parts: [prompt] },
          metadata: {}
        }
      ],
      parent_message_id: parentMessageId,
      model,
      timezone_offset_min: (/* @__PURE__ */ new Date()).getTimezoneOffset(),
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
      conversation_mode: { kind: "primary_assistant" },
      // Must stay false so the turn is persisted and recoverable after handoff.
      // Temporary chats (true) often never appear for GET /conversation polling.
      history_and_training_disabled: false,
      force_paragen: false,
      force_rate_limit: false,
      supports_buffering: true,
      supported_encodings: ["v1"],
      client_contextual_info: {
        app_name: "chatgpt.com"
      }
    };
    if (sideConversationId) {
      body.conversation_id = sideConversationId;
    }
    const headers = {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      Accept: "text/event-stream",
      "User-Agent": userAgent,
      "OAI-Language": "en-US",
      "Openai-Sentinel-Chat-Requirements-Token": sentinel.chatRequirements
    };
    if (sentinel.proof) {
      headers["Openai-Sentinel-Proof-Token"] = sentinel.proof;
    }
    let lastError = "ChatGPT conversation request failed.";
    for (const url of CONVERSATION_URLS) {
      const res = await fetch(url, {
        method: "POST",
        credentials: "include",
        headers,
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const errText = await res.text().catch(() => "");
        console.error(
          `${LOG2} conversation POST ${url} \u2192 HTTP ${res.status}`,
          errText.slice(0, 400)
        );
        lastError = `ChatGPT conversation failed (HTTP ${res.status}). Reload and re-login if needed.`;
        if (res.status === 401 || res.status === 403) {
          throw new Error(
            `ChatGPT session unavailable (HTTP ${res.status}). Reload chatgpt.com / re-login, then try again.`
          );
        }
        continue;
      }
      const parsed = await parseConversationStream(
        res,
        accessToken,
        userAgent,
        onPartial
      );
      return {
        reply: parsed.reply,
        conversationId: parsed.conversationId || sideConversationId || "",
        parentMessageId: parsed.messageId || messageId,
        model
      };
    }
    throw new Error(lastError);
  }
  async function completeViaChatGptSession(creds, req, onPartial) {
    try {
      const prompt = buildFollowUpPrompt({
        quotedText: req.quotedText,
        surroundingContext: req.surroundingContext,
        conversationExcerpt: req.conversationExcerpt,
        question: req.question
      });
      const sentinel = await fetchSentinelTokens(
        creds.accessToken,
        creds.userAgent
      );
      const model = await resolveModel(creds.accessToken, creds.userAgent);
      const result = await postConversation(
        creds.accessToken,
        creds.userAgent,
        sentinel,
        prompt,
        model,
        req.sideConversationId,
        req.sideParentMessageId,
        onPartial
      );
      if (!result.conversationId) {
        console.warn(
          `${LOG2} Reply ok but conversation_id missing; follow-ups in this thread may start a new side chat.`
        );
      }
      return {
        ok: true,
        reply: cleanChatGptText(result.reply),
        sideConversationId: result.conversationId || void 0,
        sideParentMessageId: result.parentMessageId || void 0
      };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      console.error(`${LOG2} complete failed:`, message);
      return { ok: false, error: message };
    }
  }

  // extension/core/sidebar.ts
  var HOST_ID = "ai-helper-sidebar-host";
  var STYLES = `
:host {
  all: initial;
}
* {
  box-sizing: border-box;
}
.fab {
  position: fixed;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  z-index: 2147483647;
  width: 28px;
  height: 72px;
  padding: 0;
  border: 1px solid #d8d8d4;
  border-radius: 8px;
  background: #f7f7f5;
  color: #333;
  font: 600 11px/1 "Segoe UI", system-ui, sans-serif;
  cursor: pointer;
  box-shadow: 0 2px 10px rgba(0,0,0,0.12);
  writing-mode: vertical-rl;
  text-orientation: mixed;
  letter-spacing: 0.04em;
  display: none;
}
.fab.visible {
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
.panel {
  position: fixed;
  top: 0;
  right: 0;
  height: 100vh;
  width: 360px;
  max-width: min(360px, 100vw);
  background: #f7f7f5;
  color: #1a1a1a;
  font-family: "Segoe UI", system-ui, sans-serif;
  font-size: 13px;
  line-height: 1.45;
  border-left: 1px solid #d8d8d4;
  box-shadow: -4px 0 24px rgba(0,0,0,0.08);
  display: flex;
  flex-direction: column;
  z-index: 2147483646;
  transform: translateX(0);
  transition: transform 0.2s ease;
  pointer-events: auto;
}
.panel.collapsed {
  transform: translateX(100%);
  box-shadow: none;
  pointer-events: none;
}
.header {
  padding: 14px 16px;
  border-bottom: 1px solid #e4e4e0;
  font-weight: 600;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.header span {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.collapse-btn {
  border: none;
  background: transparent;
  cursor: pointer;
  font-size: 18px;
  line-height: 1;
  color: #555;
  padding: 4px;
}
.list {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
}
.empty {
  color: #777;
  padding: 20px 12px;
  text-align: center;
}
.card {
  background: #fff;
  border: 1px solid #e4e4e0;
  border-radius: 8px;
  margin-bottom: 10px;
  overflow: hidden;
}
.card.active {
  border-color: #c9a227;
  box-shadow: 0 0 0 1px #c9a22733;
}
.card-header {
  padding: 10px 12px;
  cursor: pointer;
  user-select: none;
  display: flex;
  align-items: flex-start;
  gap: 8px;
}
.card-header-main {
  flex: 1;
  min-width: 0;
}
.close-btn {
  flex-shrink: 0;
  border: none;
  background: transparent;
  color: #888;
  font-size: 14px;
  line-height: 1;
  padding: 2px 6px;
  cursor: pointer;
  border-radius: 4px;
}
.close-btn:hover {
  background: #eee;
  color: #333;
}
.reply.streaming .body::after {
  content: "|";
  display: inline-block;
  margin-left: 1px;
  animation: blink 1s step-end infinite;
  color: #888;
}
@keyframes blink {
  50% { opacity: 0; }
}
.quote {
  font-style: italic;
  color: #444;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.meta {
  margin-top: 4px;
  font-size: 11px;
  color: #888;
}
.card-body {
  display: none;
  border-top: 1px solid #eee;
  padding: 10px 12px 12px;
}
.card.expanded .card-body {
  display: block;
}
.replies {
  max-height: 220px;
  overflow-y: auto;
  margin-bottom: 10px;
}
.reply {
  padding: 6px 8px;
  border-radius: 6px;
  margin-bottom: 6px;
}
.reply.user {
  background: #eef3ff;
}
.reply.assistant {
  background: #f3f3f0;
}
.reply .role {
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: #888;
  margin-bottom: 2px;
}
.reply .body {
  white-space: normal;
  word-break: break-word;
}
.reply .body strong {
  font-weight: 600;
}
.reply .body em {
  font-style: italic;
}
.composer {
  display: flex;
  gap: 6px;
}
.composer input {
  flex: 1;
  border: 1px solid #d0d0cc;
  border-radius: 6px;
  padding: 8px 10px;
  font: inherit;
  background: #fff;
  color: #111;
}
.composer button {
  border: none;
  border-radius: 6px;
  padding: 8px 12px;
  background: #1a1a1a;
  color: #fff;
  font: inherit;
  cursor: pointer;
}
.composer button:disabled {
  opacity: 0.5;
  cursor: default;
}
.status {
  margin-top: 6px;
  font-size: 11px;
  color: #a33;
}
`;
  var Sidebar = class {
    constructor(callbacks) {
      this.threads = [];
      this.expanded = /* @__PURE__ */ new Set();
      this.activeId = null;
      /** Start collapsed so we don't cover ChatGPT chrome until needed. */
      this.collapsed = true;
      this.callbacks = callbacks;
      let host = document.getElementById(HOST_ID);
      if (!host) {
        host = document.createElement("div");
        host.id = HOST_ID;
        document.body.appendChild(host);
      }
      this.host = host;
      this.shadow = host.shadowRoot ?? host.attachShadow({ mode: "open" });
      this.renderShell();
    }
    setThreads(threads) {
      this.threads = threads;
      this.renderList();
    }
    focusThread(threadId) {
      this.expanded.add(threadId);
      this.activeId = threadId;
      this.setCollapsed(false);
      this.renderList();
      const card = this.shadow.querySelector(
        `[data-thread-id="${CSS.escape(threadId)}"]`
      );
      card?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
    /** Update the in-flight assistant bubble without rebuilding the whole list. */
    patchAssistantReply(threadId, text) {
      const card = this.shadow.querySelector(
        `[data-thread-id="${CSS.escape(threadId)}"]`
      );
      if (!card) return;
      const replies = card.querySelector(".replies");
      if (!replies) return;
      let live = replies.querySelector(
        ".reply.assistant.streaming"
      );
      if (!live) {
        live = document.createElement("div");
        live.className = "reply assistant streaming";
        live.innerHTML = `<div class="role">assistant</div><div class="body"></div>`;
        replies.appendChild(live);
      }
      const body = live.querySelector(".body");
      if (body) body.innerHTML = formatReplyHtml(text) || "&nbsp;";
      replies.scrollTop = replies.scrollHeight;
    }
    setCollapsed(collapsed) {
      this.collapsed = collapsed;
      this.panel.classList.toggle("collapsed", collapsed);
      this.fab.classList.toggle("visible", collapsed);
      this.fab.setAttribute("aria-expanded", collapsed ? "false" : "true");
    }
    renderShell() {
      this.shadow.innerHTML = "";
      const style = document.createElement("style");
      style.textContent = STYLES;
      this.shadow.appendChild(style);
      this.fab = document.createElement("button");
      this.fab.type = "button";
      this.fab.className = "fab visible";
      this.fab.title = "Open highlight threads";
      this.fab.setAttribute("aria-label", "Open highlight threads");
      this.fab.textContent = "Threads";
      this.fab.addEventListener("click", () => this.setCollapsed(false));
      this.shadow.appendChild(this.fab);
      this.panel = document.createElement("div");
      this.panel.className = "panel collapsed";
      this.panel.innerHTML = `
      <div class="header">
        <span>Highlight threads</span>
        <button type="button" class="collapse-btn" title="Collapse" aria-label="Collapse">\u203A</button>
      </div>
      <div class="list"></div>
    `;
      this.shadow.appendChild(this.panel);
      this.listEl = this.panel.querySelector(".list");
      this.panel.querySelector(".collapse-btn")?.addEventListener("click", () => {
        this.setCollapsed(true);
      });
    }
    renderList() {
      if (this.threads.length === 0) {
        this.listEl.innerHTML = `<div class="empty">Highlight text in a reply and click \u201CAsk about this\u201D to start a thread.</div>`;
        return;
      }
      this.listEl.innerHTML = "";
      for (const thread of this.threads) {
        this.listEl.appendChild(this.buildCard(thread));
      }
    }
    buildCard(thread) {
      const card = document.createElement("div");
      card.className = "card";
      card.dataset.threadId = thread.id;
      if (this.expanded.has(thread.id)) card.classList.add("expanded");
      if (this.activeId === thread.id) card.classList.add("active");
      const header = document.createElement("div");
      header.className = "card-header";
      const main2 = document.createElement("div");
      main2.className = "card-header-main";
      main2.innerHTML = `
      <div class="quote">${escapeHtml2(thread.quotedText)}</div>
      <div class="meta">${thread.replies.length} ${thread.replies.length === 1 ? "reply" : "replies"}</div>
    `;
      main2.addEventListener("click", () => {
        if (this.expanded.has(thread.id)) {
          this.expanded.delete(thread.id);
        } else {
          this.expanded.add(thread.id);
        }
        this.activeId = thread.id;
        this.callbacks.onFocusThread(thread.id);
        this.renderList();
      });
      const collapseBtn = document.createElement("button");
      collapseBtn.type = "button";
      collapseBtn.className = "close-btn";
      const isExpanded = this.expanded.has(thread.id);
      collapseBtn.title = isExpanded ? "Collapse thread" : "Expand thread";
      collapseBtn.setAttribute(
        "aria-label",
        isExpanded ? "Collapse thread" : "Expand thread"
      );
      collapseBtn.textContent = isExpanded ? "\u25BE" : "\u25B8";
      collapseBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (this.expanded.has(thread.id)) {
          this.expanded.delete(thread.id);
        } else {
          this.expanded.add(thread.id);
          this.activeId = thread.id;
          this.callbacks.onFocusThread(thread.id);
        }
        this.renderList();
      });
      header.appendChild(main2);
      header.appendChild(collapseBtn);
      card.appendChild(header);
      const body = document.createElement("div");
      body.className = "card-body";
      const replies = document.createElement("div");
      replies.className = "replies";
      for (const r of thread.replies) {
        const div = document.createElement("div");
        div.className = `reply ${r.role}`;
        div.innerHTML = `<div class="role">${r.role}</div><div class="body">${r.role === "assistant" ? formatReplyHtml(r.text) : escapeHtml2(r.text)}</div>`;
        replies.appendChild(div);
      }
      body.appendChild(replies);
      const composer = document.createElement("div");
      composer.className = "composer";
      const input = document.createElement("input");
      input.type = "text";
      input.placeholder = "Ask about this snippet\u2026";
      const send = document.createElement("button");
      send.type = "button";
      send.textContent = "Send";
      const status = document.createElement("div");
      status.className = "status";
      const doSend = async () => {
        const question = input.value.trim();
        if (!question) return;
        send.disabled = true;
        status.textContent = "";
        try {
          const result = await this.callbacks.onSend(
            thread,
            question,
            (partial) => this.patchAssistantReply(thread.id, partial)
          );
          if (!result.ok) {
            status.textContent = result.error || "Request failed";
          } else {
            input.value = "";
          }
        } catch (err) {
          status.textContent = err instanceof Error ? err.message : String(err);
        } finally {
          send.disabled = false;
          if (this.threads.some((t) => t.id === thread.id)) {
            this.renderList();
            this.focusThread(thread.id);
          } else {
            this.renderList();
          }
        }
      };
      send.addEventListener("click", () => void doSend());
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          void doSend();
        }
      });
      composer.appendChild(input);
      composer.appendChild(send);
      body.appendChild(composer);
      body.appendChild(status);
      card.appendChild(body);
      return card;
    }
  };
  function escapeHtml2(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  async function sendAskFollowUp(payload, onPartial) {
    const message = { type: "ask-follow-up", ...payload };
    if (payload.siteId === "chatgpt") {
      try {
        console.info(
          "[ai-helper][chatgpt-session] Completing follow-up in page (direct path)"
        );
        const creds = await fetchAccessTokenFromPage();
        return await completeViaChatGptSession(creds, message, onPartial);
      } catch (err) {
        const error = err instanceof Error ? err.message : String(err);
        console.error("[ai-helper][chatgpt-session] complete failed:", error);
        return { ok: false, error };
      }
    }
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          resolve({
            ok: false,
            error: chrome.runtime.lastError.message
          });
          return;
        }
        resolve(response ?? { ok: false, error: "Empty response" });
      });
    });
  }

  // extension/core/storage.ts
  var EXTENSION_RELOAD_MSG = "Extension was reloaded \u2014 refresh this ChatGPT tab to keep using Highlight threads.";
  function storageKey(siteId, conversationId) {
    return `${siteId}:${conversationId}`;
  }
  function isExtensionAlive() {
    try {
      return Boolean(chrome?.runtime?.id);
    } catch {
      return false;
    }
  }
  function asStorageError(err) {
    const raw = err instanceof Error ? err.message : String(err);
    if (/extension context invalidated/i.test(raw) || !isExtensionAlive()) {
      return new Error(EXTENSION_RELOAD_MSG);
    }
    return err instanceof Error ? err : new Error(raw);
  }
  async function loadThreads(siteId, conversationId) {
    if (!isExtensionAlive()) return [];
    const key = storageKey(siteId, conversationId);
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get([key], (result) => {
          if (chrome.runtime.lastError) {
            console.error(
              "[ai-helper] storage load failed:",
              chrome.runtime.lastError.message
            );
            resolve([]);
            return;
          }
          const value = result[key];
          resolve(Array.isArray(value) ? value : []);
        });
      } catch (err) {
        console.error("[ai-helper] storage load threw:", asStorageError(err).message);
        resolve([]);
      }
    });
  }
  async function saveThreads(siteId, conversationId, threads) {
    if (!isExtensionAlive()) {
      throw new Error(EXTENSION_RELOAD_MSG);
    }
    const key = storageKey(siteId, conversationId);
    return new Promise((resolve, reject) => {
      try {
        chrome.storage.local.set({ [key]: threads }, () => {
          if (chrome.runtime.lastError) {
            const msg = chrome.runtime.lastError.message || "storage save failed";
            console.error("[ai-helper] storage save failed:", msg);
            reject(asStorageError(new Error(msg)));
            return;
          }
          resolve();
        });
      } catch (err) {
        reject(asStorageError(err));
      }
    });
  }

  // extension/core/engine.ts
  var EXCERPT_MAX_CHARS = 4e3;
  function createId() {
    if (typeof crypto !== "undefined" && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    return `t-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  }
  async function bootEngine(adapter) {
    let conversationId = adapter.getConversationId();
    let threads = await loadThreads(adapter.siteId, conversationId);
    const messageEls = /* @__PURE__ */ new Map();
    let dead = false;
    const markDead = (err) => {
      if (dead) return;
      dead = true;
      const msg = err instanceof Error && /reload this/i.test(err.message) ? err.message : EXTENSION_RELOAD_MSG;
      console.warn("[ai-helper]", msg, err instanceof Error ? err.message : err);
    };
    const persist = async () => {
      if (!isExtensionAlive()) {
        markDead();
        throw new Error(EXTENSION_RELOAD_MSG);
      }
      try {
        await saveThreads(adapter.siteId, conversationId, threads);
      } catch (err) {
        markDead(err);
        throw err instanceof Error ? err : new Error(String(err));
      }
    };
    const surroundingContext = (thread) => {
      const el = messageEls.get(thread.messageId);
      if (!el) return thread.quotedText;
      const raw = el.dataset.aiHelperRaw || getPlainText(el);
      const pad = 200;
      const start = Math.max(0, thread.anchorStart - pad);
      const end = Math.min(raw.length, thread.anchorEnd + pad);
      return raw.slice(start, end);
    };
    const conversationExcerpt = () => {
      if (typeof adapter.getConversationExcerpt === "function") {
        return adapter.getConversationExcerpt(EXCERPT_MAX_CHARS);
      }
      return "";
    };
    const bindMarkClicks = () => {
      for (const el of messageEls.values()) {
        el.querySelectorAll("mark[data-thread-id]").forEach((mark) => {
          const htmlMark = mark;
          if (htmlMark.dataset.aiHelperBound) return;
          htmlMark.dataset.aiHelperBound = "1";
          htmlMark.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            const id = htmlMark.dataset.threadId;
            if (id) sidebar.focusThread(id);
          });
        });
      }
    };
    const refreshHighlights = () => {
      for (const [messageId, el] of messageEls) {
        if (!adapter.isMessageComplete(el)) continue;
        const forMessage = threads.filter((t) => t.messageId === messageId);
        applyHighlightsToElement(el, forMessage);
      }
      bindMarkClicks();
    };
    const sidebar = new Sidebar({
      onFocusThread: (threadId) => {
        const mark = document.querySelector(
          `mark[data-thread-id="${CSS.escape(threadId)}"]`
        );
        if (mark) {
          mark.scrollIntoView({ behavior: "smooth", block: "center" });
          mark.style.outline = "2px solid #c9a227";
          setTimeout(() => {
            mark.style.outline = "";
          }, 1200);
        }
      },
      onSend: async (thread, question, onPartial) => {
        if (!isExtensionAlive()) {
          markDead();
          return { ok: false, error: EXTENSION_RELOAD_MSG };
        }
        const idx = threads.findIndex((t) => t.id === thread.id);
        if (idx < 0) return { ok: false, error: "Thread not found" };
        const current = threads[idx];
        threads[idx] = {
          ...current,
          replies: [
            ...current.replies,
            { role: "user", text: question, ts: Date.now() }
          ]
        };
        try {
          await persist();
        } catch (err) {
          return {
            ok: false,
            error: err instanceof Error ? err.message : String(err)
          };
        }
        sidebar.setThreads(threads);
        sidebar.focusThread(thread.id);
        const result = await sendAskFollowUp(
          {
            siteId: adapter.siteId,
            quotedText: current.quotedText,
            surroundingContext: surroundingContext(current),
            conversationExcerpt: conversationExcerpt(),
            question,
            messageId: current.messageId,
            threadId: current.id,
            sideConversationId: current.sideConversationId,
            sideParentMessageId: current.sideParentMessageId
          },
          onPartial
        );
        if (result.ok && result.reply) {
          const i = threads.findIndex((t) => t.id === thread.id);
          if (i >= 0) {
            threads[i] = {
              ...threads[i],
              sideConversationId: result.sideConversationId ?? threads[i].sideConversationId,
              sideParentMessageId: result.sideParentMessageId ?? threads[i].sideParentMessageId,
              replies: [
                ...threads[i].replies,
                { role: "assistant", text: result.reply, ts: Date.now() }
              ]
            };
            try {
              await persist();
            } catch (err) {
              return {
                ok: false,
                error: err instanceof Error ? err.message : String(err)
              };
            }
            sidebar.setThreads(threads);
          }
        }
        return result;
      }
    });
    sidebar.setThreads(threads);
    const registerMessage = (el) => {
      const messageId = adapter.getMessageId(el);
      messageEls.set(messageId, el);
      const applyWhenReady = () => {
        if (!adapter.isMessageComplete(el)) {
          setTimeout(applyWhenReady, 400);
          return;
        }
        if (!el.dataset.aiHelperRaw) {
          el.dataset.aiHelperRaw = getPlainText(el);
        }
        const forMessage = threads.filter((t) => t.messageId === messageId);
        applyHighlightsToElement(el, forMessage);
        bindMarkClicks();
      };
      applyWhenReady();
    };
    const onAsk = async (anchor) => {
      if (!isExtensionAlive()) {
        markDead();
        console.warn("[ai-helper]", EXTENSION_RELOAD_MSG);
        return;
      }
      const messageId = adapter.getMessageId(anchor.messageRoot);
      messageEls.set(messageId, anchor.messageRoot);
      if (!anchor.messageRoot.dataset.aiHelperRaw) {
        anchor.messageRoot.dataset.aiHelperRaw = getPlainText(
          anchor.messageRoot
        );
      }
      const overlapping = threads.some(
        (t) => t.messageId === messageId && !(anchor.end <= t.anchorStart || anchor.start >= t.anchorEnd)
      );
      if (overlapping) {
        console.warn(
          "[ai-helper] Selection overlaps an existing highlight; create skipped."
        );
        return;
      }
      const thread = {
        id: createId(),
        messageId,
        anchorStart: anchor.start,
        anchorEnd: anchor.end,
        quotedText: anchor.quotedText,
        replies: []
      };
      threads = [...threads, thread];
      try {
        await persist();
      } catch (err) {
        threads = threads.filter((t) => t.id !== thread.id);
        console.warn(
          "[ai-helper] could not save new thread:",
          err instanceof Error ? err.message : err
        );
        return;
      }
      sidebar.setThreads(threads);
      sidebar.focusThread(thread.id);
      refreshHighlights();
    };
    const detachSelection = attachSelectionHandler(
      () => adapter.getMessageContainers(),
      (anchor) => {
        void onAsk(anchor);
      }
    );
    adapter.onNewMessage((el) => registerMessage(el));
    const convPoll = setInterval(() => {
      if (dead || !isExtensionAlive()) {
        markDead();
        clearInterval(convPoll);
        return;
      }
      const next = adapter.getConversationId();
      if (next !== conversationId) {
        conversationId = next;
        void (async () => {
          threads = await loadThreads(adapter.siteId, conversationId);
          messageEls.clear();
          sidebar.setThreads(threads);
          for (const el of adapter.getMessageContainers()) {
            registerMessage(el);
          }
        })();
      }
    }, 1e3);
    console.info(
      `[ai-helper] Engine started for site="${adapter.siteId}" conversation="${conversationId}" (${threads.length} threads loaded)`
    );
    return () => {
      detachSelection();
      clearInterval(convPoll);
    };
  }

  // extension/content-scripts/inject.ts
  function resolveAdapter(hostname) {
    if (hostname === "chatgpt.com" || hostname === "www.chatgpt.com") {
      return createChatGptAdapter();
    }
    return null;
  }
  async function main() {
    const adapter = resolveAdapter(location.hostname);
    if (!adapter) {
      console.warn(
        `[ai-helper] No adapter for hostname "${location.hostname}". Extension idle.`
      );
      return;
    }
    try {
      await bootEngine(adapter);
    } catch (err) {
      console.error("[ai-helper] Failed to boot engine:", err);
    }
  }
  void main();
})();
/*! Bundled license information:

js-sha3/build/sha3.mjs:
  (**
   * [js-sha3]{@link https://github.com/emn178/js-sha3}
   *
   * @version 0.13.0
   * @author Chen, Yi-Cyuan [emn178@gmail.com]
   * @copyright Chen, Yi-Cyuan 2015-2026
   * @license MIT
   *)
*/
//# sourceMappingURL=content.js.map
